try {
  importScripts(
    "js/rxjs.umd.min.js",
    "js/defaults.js",
    "js/messaging.js",
    "js/content-handlers.js",  
    "js/events.js"
  )
}
catch (err) {
  console.error(err)
}


// // In your background script or popup
// chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
//     if (request.action === "translateSelectionToHindi") {
//         chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
//             chrome.tabs.sendMessage(tabs[0].id, {
//                 action: "translateSelectionToHindi"
//             }, (response) => {
//                 if (chrome.runtime.lastError) {
//                     console.error('Message error:', chrome.runtime.lastError);
//                     sendResponse({ 
//                         success: false, 
//                         error: "Content script not available" 
//                     });
//                     return;
//                 }
                
//                 if (response && !response.success) {
//                     console.error('Translation failed:', response.error);
//                     // Show error to user
//                     showErrorNotification(response.error || 'Translation failed');
//                 }
                
//                 sendResponse(response);
//             });
//         });
//         return true;
//     }
// });

// function showErrorNotification(message) {
//     // Implement your error notification UI here
//     console.error('Translation Error:', message);
// }

// // // In your background message listener:
// // brapi.runtime.onMessage.addListener((request, sender, sendResponse) => {
// //   if (request.action === "backgroundTranslate") {
// //     if (typeof HindiTranslator === 'undefined') {
// //       sendResponse({ error: "Translator not available. Please refresh the page." });
// //       return true;
// //     }
    
// //     const translator = new HindiTranslator();
// //     translator.translate(request.text)
// //       .then(result => sendResponse({ translation: result }))
// //       .catch(error => sendResponse({ error: error.message }));
// //     return true;
// //   }
// // });