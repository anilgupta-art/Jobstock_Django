// translator.js - Simplified and more robust version
(function() {
    'use strict';
    
    console.log('Loading HindiTranslator...');
    
    function HindiTranslator() {
        this.apis = [
            this.myMemoryTranslate.bind(this),
            this.googleTranslateFallback.bind(this),
            this.libretranslateFallback.bind(this)
        ];
    }

    HindiTranslator.prototype.translate = function(text) {
        var self = this;
        return new Promise(function(resolve, reject) {
            if (!text || typeof text !== 'string' || text.trim() === '') {
                resolve(text);
                return;
            }

            // Try each API sequentially
            var tryApi = function(index) {
                if (index >= self.apis.length) {
                    reject(new Error('All translation APIs failed'));
                    return;
                }

                self.apis[index](text)
                    .then(function(result) {
                        if (result && result !== text) {
                            resolve(result);
                        } else {
                            tryApi(index + 1);
                        }
                    })
                    .catch(function(error) {
                        console.warn('Translation API failed:', error);
                        tryApi(index + 1);
                    });
            };

            tryApi(0);
        });
    };

    HindiTranslator.prototype.myMemoryTranslate = function(text) {
        return fetch(
            'https://api.mymemory.translated.net/get?q=' + 
            encodeURIComponent(text) + 
            '&langpair=en|hi'
        )
        .then(function(response) {
            if (!response.ok) throw new Error('MyMemory API error: ' + response.status);
            return response.json();
        })
        .then(function(data) {
            return data.responseData.translatedText;
        });
    };

    HindiTranslator.prototype.googleTranslateFallback = function(text) {
        return fetch(
            'https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=hi&dt=t&q=' + 
            encodeURIComponent(text)
        )
        .then(function(response) {
            if (!response.ok) throw new Error('Google Translate API error: ' + response.status);
            return response.json();
        })
        .then(function(data) {
            return data[0][0][0];
        });
    };

    HindiTranslator.prototype.libretranslateFallback = function(text) {
        return fetch('https://libretranslate.com/translate', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify({
                q: text,
                source: 'en',
                target: 'hi',
                format: 'text'
            })
        })
        .then(function(response) {
            if (!response.ok) throw new Error('LibreTranslate API error: ' + response.status);
            return response.json();
        })
        .then(function(data) {
            return data.translatedText;
        });
    };

    // Expose to global scope
    window.HindiTranslator = HindiTranslator;
    console.log('HindiTranslator loaded successfully');
})();