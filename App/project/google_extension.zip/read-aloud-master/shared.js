// shared-languages.js
const SUPPORTED_LANGUAGES = {
    'afrikaans': { code: 'af', name: 'Afrikaans', source: true, target: true },
    'albanian': { code: 'sq', name: 'Albanian', source: true, target: true },
    'arabic': { code: 'ar', name: 'Arabic', source: true, target: true },
    'armenian': { code: 'hy', name: 'Armenian', source: true, target: true },
    'auto': { code: 'auto', name: 'Auto Detect', source: true, target: false },
    'azerbaijani': { code: 'az', name: 'Azerbaijani', source: true, target: true },
    'basque': { code: 'eu', name: 'Basque', source: true, target: true },
    'belarusian': { code: 'be', name: 'Belarusian', source: true, target: true },
    'bosnian': { code: 'bs', name: 'Bosnian', source: true, target: true },
    'bulgarian': { code: 'bg', name: 'Bulgarian', source: true, target: true },
    'burmese': { code: 'my', name: 'Burmese', source: true, target: true },
    'catalan': { code: 'ca', name: 'Catalan', source: true, target: true },
    'chinese': { code: 'zh', name: 'Chinese', source: true, target: true },
    'croatian': { code: 'hr', name: 'Croatian', source: true, target: true },
    'czech': { code: 'cs', name: 'Czech', source: true, target: true },
    'danish': { code: 'da', name: 'Danish', source: true, target: true },
    'dutch': { code: 'nl', name: 'Dutch', source: true, target: true },
    'english': { code: 'en', name: 'English', source: true, target: true },
    'esperanto': { code: 'eo', name: 'Esperanto', source: true, target: true },
    'estonian': { code: 'et', name: 'Estonian', source: true, target: true },
    'filipino': { code: 'tl', name: 'Filipino', source: true, target: true },
    'finnish': { code: 'fi', name: 'Finnish', source: true, target: true },
    'french': { code: 'fr', name: 'French', source: true, target: true },
    'galician': { code: 'gl', name: 'Galician', source: true, target: true },
    'georgian': { code: 'ka', name: 'Georgian', source: true, target: true },
    'german': { code: 'de', name: 'German', source: true, target: true },
    'greek': { code: 'el', name: 'Greek', source: true, target: true },
    'haitian creole': { code: 'ht', name: 'Haitian Creole', source: true, target: true },
    'hawaiian': { code: 'haw', name: 'Hawaiian', source: true, target: true },
    'hebrew': { code: 'he', name: 'Hebrew', source: true, target: true },
    'hindi': { code: 'hi', name: 'Hindi', source: true, target: true },
    'hungarian': { code: 'hu', name: 'Hungarian', source: true, target: true },
    'icelandic': { code: 'is', name: 'Icelandic', source: true, target: true },
    'indonesian': { code: 'id', name: 'Indonesian', source: true, target: true },
    'irish': { code: 'ga', name: 'Irish', source: true, target: true },
    'italian': { code: 'it', name: 'Italian', source: true, target: true },
    'japanese': { code: 'ja', name: 'Japanese', source: true, target: true },
    'javanese': { code: 'jv', name: 'Javanese', source: true, target: true },
    'kannada': { code: 'kn', name: 'Kannada', source: true, target: true },
    'kazakh': { code: 'kk', name: 'Kazakh', source: true, target: true },
    'khmer': { code: 'km', name: 'Khmer', source: true, target: true },
    'korean': { code: 'ko', name: 'Korean', source: true, target: true },
    'lao': { code: 'lo', name: 'Lao', source: true, target: true },
    'latin': { code: 'la', name: 'Latin', source: true, target: true },
    'latvian': { code: 'lv', name: 'Latvian', source: true, target: true },
    'lithuanian': { code: 'lt', name: 'Lithuanian', source: true, target: true },
    'macedonian': { code: 'mk', name: 'Macedonian', source: true, target: true },
    'malagasy': { code: 'mg', name: 'Malagasy', source: true, target: true },
    'malay': { code: 'ms', name: 'Malay', source: true, target: true },
    'maltese': { code: 'mt', name: 'Maltese', source: true, target: true },
    'marathi': { code: 'mr', name: 'Marathi', source: true, target: true },
    'mongolian': { code: 'mn', name: 'Mongolian', source: true, target: true },
    'nepali': { code: 'ne', name: 'Nepali', source: true, target: true },
    'norwegian': { code: 'no', name: 'Norwegian', source: true, target: true },
    'pashto': { code: 'ps', name: 'Pashto', source: true, target: true },
    'persian': { code: 'fa', name: 'Persian', source: true, target: true },
    'polish': { code: 'pl', name: 'Polish', source: true, target: true },
    'portuguese': { code: 'pt', name: 'Portuguese', source: true, target: true },
    'punjabi': { code: 'pa', name: 'Punjabi', source: true, target: true },
    'romanian': { code: 'ro', name: 'Romanian', source: true, target: true },
    'russian': { code: 'ru', name: 'Russian', source: true, target: true },
    'samoan': { code: 'sm', name: 'Samoan', source: true, target: true },
    'scottish gaelic': { code: 'gd', name: 'Scottish Gaelic', source: true, target: true },
    'serbian': { code: 'sr', name: 'Serbian', source: true, target: true },
    'sindhi': { code: 'sd', name: 'Sindhi', source: true, target: true },
    'sinhala': { code: 'si', name: 'Sinhala', source: true, target: true },
    'slovak': { code: 'sk', name: 'Slovak', source: true, target: true },
    'slovenian': { code: 'sl', name: 'Slovenian', source: true, target: true },
    'somali': { code: 'so', name: 'Somali', source: true, target: true },
    'spanish': { code: 'es', name: 'Spanish', source: true, target: true },
    'sundanese': { code: 'su', name: 'Sundanese', source: true, target: true },
    'swahili': { code: 'sw', name: 'Swahili', source: true, target: true },
    'swedish': { code: 'sv', name: 'Swedish', source: true, target: true },
    'tajik': { code: 'tg', name: 'Tajik', source: true, target: true },
    'tamil': { code: 'ta', name: 'Tamil', source: true, target: true },
    'telugu': { code: 'te', name: 'Telugu', source: true, target: true },
    'thai': { code: 'th', name: 'Thai', source: true, target: true },
    'turkish': { code: 'tr', name: 'Turkish', source: true, target: true },
    'ukrainian': { code: 'uk', name: 'Ukrainian', source: true, target: true },
    'urdu': { code: 'ur', name: 'Urdu', source: true, target: true },
    'uyghur': { code: 'ug', name: 'Uyghur', source: true, target: true },
    'uzbek': { code: 'uz', name: 'Uzbek', source: true, target: true },
    'vietnamese': { code: 'vi', name: 'Vietnamese', source: true, target: true },
    'welsh': { code: 'cy', name: 'Welsh', source: true, target: true },
    'yiddish': { code: 'yi', name: 'Yiddish', source: true, target: true },
    'yoruba': { code: 'yo', name: 'Yoruba', source: true, target: true },
    'zulu': { code: 'zu', name: 'Zulu', source: true, target: true }
};
// Utility functions
const LanguageUtils = {
    getLanguageByName: function(name) {
        return Object.values(SUPPORTED_LANGUAGES).find(lang => 
            lang.name.toLowerCase() === name.toLowerCase()
        );
    },
    
    getLanguageByCode: function(code) {
        return Object.values(SUPPORTED_LANGUAGES).find(lang => 
            lang.code === code
        );
    },
    
    getSourceLanguages: function() {
        return Object.values(SUPPORTED_LANGUAGES).filter(lang => lang.source);
    },
    
    getTargetLanguages: function() {
        return Object.values(SUPPORTED_LANGUAGES).filter(lang => lang.target);
    },
    
    isValidSourceLanguage: function(language) {
        const lang = typeof language === 'string' ? 
            this.getLanguageByName(language) || this.getLanguageByCode(language) : 
            language;
        return lang && lang.source;
    },
    
    isValidTargetLanguage: function(language) {
        const lang = typeof language === 'string' ? 
            this.getLanguageByName(language) || this.getLanguageByCode(language) : 
            language;
        return lang && lang.target;
    },
    
    getLanguageDisplayName: function(language) {
        const lang = typeof language === 'string' ? 
            this.getLanguageByName(language) || this.getLanguageByCode(language) : 
            language;
        return lang ? lang.name : 'Unknown';
    }
};

// Export for different environments
if (typeof module !== 'undefined' && module.exports) {
    // Node.js/CommonJS
    module.exports = { SUPPORTED_LANGUAGES, LanguageUtils };
} else if (typeof define === 'function' && define.amd) {
    // AMD
    define([], function() {
        return { SUPPORTED_LANGUAGES, LanguageUtils };
    });
} else {
    // Browser global
    window.SUPPORTED_LANGUAGES = SUPPORTED_LANGUAGES;
    window.LanguageUtils = LanguageUtils;
}