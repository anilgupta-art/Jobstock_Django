// Hindi Translator functionality
let HindiTranslator;
let translatorReady = false;

// Load translator script and wait for it to be ready
function initTranslator() {
    return new Promise((resolve, reject) => {
        if (window.HindiTranslator) {
            HindiTranslator = window.HindiTranslator;
            translatorReady = true;
            resolve();
            return;
        }
        
        const script = document.createElement('script');
        script.src = chrome.runtime.getURL('translator.js');
        
        script.onload = () => {
            // Check if the translator is actually available
            if (typeof window.HindiTranslator === 'undefined') {
                console.error('HindiTranslator not found in window object');
                reject(new Error('HindiTranslator not found'));
                return;
            }
            
            HindiTranslator = window.HindiTranslator;
            translatorReady = true;
            console.log('Hindi Translator loaded successfully');
            resolve();
        };
        
        script.onerror = (error) => {
            console.error('Failed to load translator script:', error);
            reject(error);
        };
        
        document.head.appendChild(script);
    });
}

// Initialize translator with retry mechanism
async function initializeTranslatorWithRetry(maxRetries = 3) {
    for (let i = 0; i < maxRetries; i++) {
        try {
            await initTranslator();
            console.log('Hindi Translator initialized successfully');
            return true;
        } catch (error) {
            console.warn(`Translator initialization attempt ${i + 1} failed:`, error);
            if (i === maxRetries - 1) {
                console.error('All translator initialization attempts failed');
                return false;
            }
            // Wait before retrying
            await new Promise(resolve => setTimeout(resolve, 1000 * (i + 1)));
        }
    }
    return false;
}

// Initialize translator
initializeTranslatorWithRetry().then((success) => {
    translatorReady = success;
    console.log('Hindi Translator initialization status:', success);
});

// Your existing message listener
registerMessageListener("contentScript", {
    getRequireJs: getRequireJs,
    getDocumentInfo: getInfo,
    getCurrentIndex: getCurrentIndex,
    getTexts: getTexts
});

// Add Hindi translation message listener
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "translateText") {
        handleTranslation(request.text, sendResponse);
        return true;
    }
    else if (request.action === "translateSelection") {
        handleTranslation(request.text, sendResponse);
        return true;
    }
    else if (request.action === "translateSelectionToHindi") {
        const selectedText = window.getSelection().toString().trim();
        if (selectedText) {
            handleTranslation(selectedText, sendResponse);
            return true;
        }
    }
    else if (request.action === "showTranslation") {
        showTranslationPopup(request.originalText, request.translatedText);
        sendResponse({ success: true });
        return true;
    }
    
    // Handle other existing messages if needed
    return false;
});

async function handleTranslation(text, sendResponse) {
    if (!translatorReady) {
        // Try to initialize if not ready
        const success = await initializeTranslatorWithRetry(2);
        if (!success) {
            sendResponse({ 
                success: false, 
                error: "Translator not available. Please try again." 
            });
            return;
        }
    }

    try {
        const translator = new HindiTranslator();
        const translation = await translator.translate(text);
        sendResponse({ 
            success: true, 
            translation: translation,
            originalText: text
        });
    } catch (error) {
        console.error('Translation error:', error);
        sendResponse({ 
            success: false, 
            error: error.message,
            fallback: "Translation service unavailable. Please check your connection."
        });
    }
}

// Rest of your existing code remains the same...

(function() {
  // Your existing message listener
  registerMessageListener("contentScript", {
    getRequireJs: getRequireJs,
    getDocumentInfo: getInfo,
    getCurrentIndex: getCurrentIndex,
    getTexts: getTexts
  })

  // Add Hindi translation message listener
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "translateText") {
        handleTranslation(request.text, sendResponse);
        return true;
    }
    else if (request.action === "translateSelection") {
        handleTranslation(request.text, sendResponse);
        return true;
    }
    else if (request.action === "translateSelectionToHindi") {
        const selectedText = window.getSelection().toString().trim();
        if (selectedText) {
            handleTranslation(selectedText, sendResponse);
            return true;
        }
    }
    else if (request.action === "showTranslation") {
        showTranslationPopup(request.originalText, request.translatedText);
        sendResponse({ success: true });
        return true;
    }
    
    // Preserve existing message handling if any
  });

  async function handleTranslation(text, sendResponse) {
    if (!translatorReady) {
        // Wait for translator to be ready
        await initTranslator();
    }

    if (!HindiTranslator) {
        sendResponse({ success: false, error: "Translator not available" });
        return;
    }

    try {
        const translator = new HindiTranslator();
        const translation = await translator.translate(text);
        sendResponse({ success: true, translation: translation });
    } catch (error) {
        console.error('Translation error:', error);
        sendResponse({ success: false, error: error.message });
    }
  }

  // Add right-click context menu translation
  document.addEventListener('contextmenu', (event) => {
    const selectedText = window.getSelection().toString().trim();
    if (selectedText) {
        chrome.storage.local.set({ selectedText: selectedText });
    }
  });

  // Function to show translation popup
  function showTranslationPopup(originalText, translatedText) {
    // Remove existing popup if any
    const existingPopup = document.getElementById('hindi-translation-popup');
    if (existingPopup) {
      existingPopup.remove();
    }

    // Create translation popup
    const popup = document.createElement('div');
    popup.id = 'hindi-translation-popup';
    popup.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: white;
      border: 2px solid #4285f4;
      border-radius: 8px;
      padding: 15px;
      max-width: 300px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      z-index: 10000;
      font-family: Arial, sans-serif;
    `;

    popup.innerHTML = `
      <div style="margin-bottom: 10px;">
        <strong>English:</strong>
        <div style="color: #666; margin-top: 5px;">${escapeHtml(originalText)}</div>
      </div>
      <div>
        <strong>Hindi:</strong>
        <div style="color: #333; margin-top: 5px; font-size: 16px;">${escapeHtml(translatedText)}</div>
      </div>
      <button style="margin-top: 10px; padding: 5px 10px; background: #4285f4; color: white; border: none; border-radius: 4px; cursor: pointer;">
        Close
      </button>
    `;

    // Add close button functionality
    const closeButton = popup.querySelector('button');
    closeButton.addEventListener('click', () => {
      popup.remove();
    });

    // Auto-close after 10 seconds
    setTimeout(() => {
      if (document.contains(popup)) {
        popup.remove();
      }
    }, 10000);

    document.body.appendChild(popup);
  }

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }


  // Rest of your existing functions remain unchanged
  function getInfo() {
    return {
      url: location.href,
      title: document.title,
      lang: getLang(),
    }
  }

  function getLang() {
    var lang = document.documentElement.lang || $("html").attr("xml:lang");
    if (lang) lang = lang.split(",",1)[0].replace(/_/g, '-');
    return lang;
  }

  function getRequireJs() {
    if (location.hostname == "docs.google.com") {
      if (/^\/presentation\/d\//.test(location.pathname)) return ["js/content/google-slides.js"];
      else if (/\/document\/d\//.test(location.pathname)) return ["js/content/googleDocsUtil.js", "js/content/google-doc.js"];
      else if ($(".drive-viewer-paginated-scrollable").length) return ["js/content/google-drive-doc.js"];
      else return ["js/content/html-doc.js"];
    }
    else if (location.hostname == "drive.google.com") {
      if ($(".drive-viewer-paginated-scrollable").length) return ["js/content/google-drive-doc.js"];
      else return ["js/content/google-drive-preview.js"];
    }
    else if (location.hostname == "onedrive.live.com" && $(".OneUp-pdf--loaded").length) return ["js/content/onedrive-doc.js"];
    else if (/^read\.amazon\./.test(location.hostname)) return ["js/content/kindle-book.js"];
    else if (location.hostname.endsWith(".khanacademy.org")) return ["js/content/khan-academy.js"];
    else if (location.hostname.endsWith("acrobatiq.com")) return ["js/content/html-doc.js", "js/content/acrobatiq.js"];
    else if (location.hostname == "digital.wwnorton.com") return ["js/content/html-doc.js", "js/content/wwnorton.js"];
    else if (location.hostname == "plus.pearson.com") return ["js/content/html-doc.js", "js/content/pearson.js"];
    else if (location.hostname == "www.ixl.com") return ["js/content/ixl.js"];
    else if (location.hostname == "www.webnovel.com" && location.pathname.startsWith("/book/")) return ["js/content/webnovel.js"];
    else if (location.hostname == "archiveofourown.org") return ["js/content/archiveofourown.js"];
    else if (location.hostname == "chat.openai.com") return ["js/content/chatgpt.js"];
    else if (location.pathname.match(/readaloud\.html$/)
      || location.pathname.match(/\.pdf$/)
      || $("embed[type='application/pdf']").length
      || $("iframe[src*='.pdf']").length) return ["js/content/pdf-doc.js"];
    else if (/^\d+\.\d+\.\d+\.\d+$/.test(location.hostname)
        && location.port === "1122"
        && location.protocol === "http:"
        && location.pathname === "/bookshelf/index.html") return  ["js/content/yd-app-web.js"];
    else return ["js/content/html-doc.js"];
  }

  async function getCurrentIndex() {
    if (await getSelectedText()) return -100;
    else return readAloudDoc.getCurrentIndex();
  }

  async function getTexts(index, quietly) {
    if (index < 0) {
      if (index == -100) return (await getSelectedText()).split(paragraphSplitter);
      else return null;
    }
    else {
      return Promise.resolve(readAloudDoc.getTexts(index, quietly))
        .then(function(texts) {
          if (texts && Array.isArray(texts)) {
            if (!quietly) console.log(texts.join("\n\n"));
          }
          return texts;
        })
    }
  }

  function getSelectedText() {
    if (readAloudDoc.getSelectedText) return readAloudDoc.getSelectedText()
    return window.getSelection().toString().trim();
  }


  getSettings()
    .then(settings => {
      if (settings.fixBtSilenceGap)
        setInterval(updateSilenceTrack.bind(null, Math.random()), 5000)
    })

  async function updateSilenceTrack(providerId) {
    if (!audioCanPlay()) return;
    const silenceTrack = getSilenceTrack()
    try {
      const should = await sendToPlayer({method: "shouldPlaySilence", args: [providerId]})
      if (should) silenceTrack.start()
      else silenceTrack.stop()
    }
    catch (err) {
      silenceTrack.stop()
    }
  }

  function audioCanPlay() {
    return navigator.userActivation && navigator.userActivation.hasBeenActive
  }

  async function sendToPlayer(message) {
    message.dest = "player"
    const result = await brapi.runtime.sendMessage(message)
    if (result && result.error) throw result.error
    else return result
  }
})()


//helpers --------------------------

var paragraphSplitter = /(?:\s*\r?\n\s*){2,}/;

function getInnerText(elem) {
  var text = elem.innerText;
  return text ? text.trim() : "";
}

function isNotEmpty(text) {
  return text;
}

function fixParagraphs(texts) {
  var out = [];
  var para = "";
  for (var i=0; i<texts.length; i++) {
    if (!texts[i]) {
      if (para) {
        out.push(para);
        para = "";
      }
      continue;
    }
    if (para) {
      if (/[-\u2013\u2014]$/.test(para)) para = para.substr(0, para.length-1);
      else para += " ";
    }
    para += texts[i].replace(/[-\u2013\u2014]\r?\n/g, "");
    if (texts[i].match(/[.!?:)"'\u2019\u201d]$/)) {
      out.push(para);
      para = "";
    }
  }
  if (para) out.push(para);
  return out;
}

function tryGetTexts(getTexts, millis) {
  return waitMillis(500)
    .then(getTexts)
    .then(function(texts) {
      if (texts && !texts.length && millis-500 > 0) return tryGetTexts(getTexts, millis-500);
      else return texts;
    })
}

function loadPageScript(url) {
  if (!$("head").length) $("<head>").prependTo("html");
  $.ajax({
    dataType: "script",
    cache: true,
    url: url
  });
}

function simulateMouseEvent(element, eventName, coordX, coordY) {
  element.dispatchEvent(new MouseEvent(eventName, {
    view: window,
    bubbles: true,
    cancelable: true,
    clientX: coordX,
    clientY: coordY,
    button: 0
  }));
}

function simulateClick(elementToClick) {
  var box = elementToClick.getBoundingClientRect(),
      coordX = box.left + (box.right - box.left) / 2,
      coordY = box.top + (box.bottom - box.top) / 2;
  simulateMouseEvent (elementToClick, "mousedown", coordX, coordY);
  simulateMouseEvent (elementToClick, "mouseup", coordX, coordY);
  simulateMouseEvent (elementToClick, "click", coordX, coordY);
}

const getMath = (function() {
  let promise = Promise.resolve(null)
  return () => promise = promise.then(math => math || makeMath())
})();

async function makeMath() {
  const getXmlFromMathEl = function(mathEl) {
    const clone = mathEl.cloneNode(true)
    $("annotation, annotation-xml", clone).remove()
    removeAllAttrs(clone, true)
    return clone.outerHTML
  }

  //determine the mml markup
  const math =
    when(document.querySelector(".MathJax, .MathJax_Preview"), {
      selector: ".MathJax[data-mathml]",
      getXML(el) {
        const mathEl = el.querySelector("math")
        return mathEl ? getXmlFromMathEl(mathEl) : el.getAttribute("data-mathml")
      },
    })
    .when(() => document.querySelector("math"), {
      selector: "math",
      getXML: getXmlFromMathEl,
    })
    .else(null)

  if (!math) return null
  const elems = $(math.selector).get()
  if (!elems.length) return null

  //create speech surrogates
  try {
    const xmls = elems.map(math.getXML)
    const texts = await ajaxPost(config.serviceUrl + "/read-aloud/mathml", xmls, "json").then(JSON.parse)
    elems.forEach((el, i) => $("<span>").addClass("readaloud-mathml").text(texts[i] || "math expression").insertBefore(el))
  }
  catch (err) {
    console.error(err)
    return {
      show() {},
      hide() {}
    }
  }

  //return functions to toggle between mml and speech
  return {
    show() {
      for (const el of elems) el.style.setProperty("display", "none", "important")
      $(".readaloud-mathml").show()
    },
    hide() {
      $(elems).css("display", "")
      $(".readaloud-mathml").hide()
    }
  }
}