// Optional: Add context menu
chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
        id: "translateToHindi",
        title: "Translate to Hindi",
        contexts: ["selection"]
    });
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === "translateToHindi" && info.selectionText) {
        // Send message to content script to handle translation
        chrome.tabs.sendMessage(tab.id, {
            action: "translateSelection",
            text: info.selectionText
        });
    }
});

// Optional: Handle messages from other parts of extension
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "backgroundTranslate") {
        const translator = new HindiTranslator();
        translator.translate(request.text)
            .then(result => sendResponse({ translation: result }))
            .catch(error => sendResponse({ error: error.message }));
        return true; // Will respond asynchronously
    }
});