document.addEventListener('DOMContentLoaded', function() {
    const inputText = document.getElementById('inputText');
    const translateBtn = document.getElementById('translateBtn');
    const resultDiv = document.getElementById('result');

    translateBtn.addEventListener('click', async function() {
        const text = inputText.value.trim();
        if (!text) return;

        resultDiv.textContent = 'Translating...';
        
        try {
            const translator = new HindiTranslator();
            const translation = await translator.translate(text);
            resultDiv.textContent = translation;
        } catch (error) {
            resultDiv.textContent = 'Translation failed: ' + error.message;
        }
    });

    // Optional: Load selected text from page
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.scripting.executeScript({
            target: {tabId: tabs[0].id},
            function: () => window.getSelection().toString().trim()
        }, (results) => {
            if (results && results[0] && results[0].result) {
                inputText.value = results[0].result;
            }
        });
    });
});