// Inject translator
const script = document.createElement('script');
script.src = chrome.runtime.getURL('translator.js');
document.head.appendChild(script);

// Listen for messages from popup or background
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "translateText") {
        const translator = new HindiTranslator();
        translator.translate(request.text)
            .then(result => sendResponse({ success: true, translation: result }))
            .catch(error => sendResponse({ success: false, error: error.message }));
        
        return true; // Will respond asynchronously
    }
});

// Optional: Add right-click context menu translation
document.addEventListener('contextmenu', (event) => {
    const selectedText = window.getSelection().toString().trim();
    if (selectedText) {
        // Store selected text for later use
        chrome.storage.local.set({ selectedText: selectedText });
    }
});