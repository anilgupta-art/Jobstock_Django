class HindiTranslator {
    constructor() {
        this.apis = [
            this.libretranslate,
            this.googleTranslate,
            this.myMemoryTranslate
        ];
    }

    async translate(text) {
        if (!text || text.trim() === '') return text;
        
        // Try each API in sequence until one works
        for (const api of this.apis) {
            try {
                const result = await api.call(this, text);
                if (result && result !== text) {
                    return result;
                }
            } catch (error) {
                console.warn(`API failed: ${api.name}`);
                continue;
            }
        }
        return text; // Return original if all fail
    }

    async libretranslate(text) {
        const response = await fetch('https://libretranslate.com/translate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                q: text,
                source: 'en',
                target: 'hi',
                format: 'text'
            })
        });
        
        if (!response.ok) throw new Error('LibreTranslate API error');
        
        const data = await response.json();
        return data.translatedText;
    }

    async googleTranslate(text) {
        const response = await fetch(
            `https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=hi&dt=t&q=${encodeURIComponent(text)}`
        );
        
        if (!response.ok) throw new Error('Google Translate API error');
        
        const data = await response.json();
        return data[0][0][0];
    }

    async myMemoryTranslate(text) {
        const response = await fetch(
            `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=en|hi`
        );
        
        if (!response.ok) throw new Error('MyMemory API error');
        
        const data = await response.json();
        return data.responseData.translatedText;
    }
}