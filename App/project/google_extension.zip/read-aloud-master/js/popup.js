var queryString = getQueryString()
const playerCheckIn$ = new rxjs.Subject()

registerMessageListener("popup", {
  playerCheckIn() {
    playerCheckIn$.next()
  }
})

const piperInitializingSubject = new rxjs.Subject()
piperInitializingSubject
  .pipe(
    rxjs.distinctUntilChanged()
  )
  .subscribe(isInitializing => {
    if (isInitializing) $("#status").text("Piper engine initializing...").show()
    else $("#status").hide()
  })

$(function() {
  if (queryString.isPopup) $("body").addClass("is-popup")
  else getCurrentTab().then(function(currentTab) {return updateSettings({readAloudTab: currentTab.id})})
  
  // Initialize Hindi Translator functionality
  initHindiTranslator();
})



getSettings(["showHighlighting", "readAloudTab"]).then(async settings => {
  if (settings.showHighlighting == 2 && queryString.isPopup) {
    await popout(settings.readAloudTab)
  } else {
    await init()
  }
}).catch(handleError)

// Hindi & Multi-language Translator functionality
function initHindiTranslator() {
  const inputText = document.getElementById('inputText');
  const translateBtn = document.getElementById('translateBtn');
  const resultDiv = document.getElementById('result');
  const sourceLang = document.getElementById('sourceLang');
  const destLang = document.getElementById('destLang');
  const saveLangBtn = document.getElementById('saveLangBtn');
  inputText.value=sessionStorage.getItem('getSelectionValue');

  if (!inputText || !translateBtn || !resultDiv || !sourceLang || !destLang || !saveLangBtn) {
    console.log('Translator elements not found');
    return;
  }

  // Populate language dropdowns
  function populateLangDropdowns() {
    sourceLang.innerHTML = '';
    destLang.innerHTML = '';
    const srcs = window.LanguageUtils.getSourceLanguages();
    const tgts = window.LanguageUtils.getTargetLanguages();
    srcs.forEach(lang => {
      const opt = document.createElement('option');
      opt.value = lang.code;
      opt.textContent = lang.name;
      sourceLang.appendChild(opt);
    });
    tgts.forEach(lang => {
      const opt = document.createElement('option');
      opt.value = lang.code;
      opt.textContent = lang.name;
      destLang.appendChild(opt);
    });
  }

  // Restore saved languages
  function restoreLangSelection() {
    chrome.storage.local.get(['sourceLang', 'destLang'], (data) => {
      sourceLang.value = data.sourceLang || 'en';
      destLang.value = data.destLang || 'hi';
    });
  }

  // Save selected languages
  saveLangBtn.addEventListener('click', function() {
    chrome.storage.local.set({
      sourceLang: sourceLang.value,
      destLang: destLang.value
    }, () => {
      saveLangBtn.textContent = 'Saved!';
      setTimeout(() => saveLangBtn.textContent = 'Save Languages', 1000);
    });
  });

  // Translation logic (multi-language support)
  translateBtn.addEventListener('click', async function() {
    const text = inputText.value.trim();
    if (!text) return;
    resultDiv.textContent = 'Translating...';

    try {
      // Use MultiLangTranslator for all language pairs
      if (window.MultiLangTranslator) {
        const translator = new window.MultiLangTranslator();
        const translation = await translator.translate(text, sourceLang.value, destLang.value);
        resultDiv.textContent = translation;
      } else if (sourceLang.value === 'en' && destLang.value === 'hi' && window.HindiTranslator) {
        // Fallback for legacy HindiTranslator
        const translator = new window.HindiTranslator();
        const translation = await translator.translate(text);
        resultDiv.textContent = translation;
      } else {
        resultDiv.textContent = `[${window.LanguageUtils.getLanguageDisplayName(sourceLang.value)}→${window.LanguageUtils.getLanguageDisplayName(destLang.value)}] Translation not implemented.`;
      }
    } catch (error) {
      resultDiv.textContent = 'Translation failed: ' + error.message;
    }
  });

  // Load selected text from page when popup opens
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    chrome.scripting.executeScript({
      target: {tabId: tabs[0].id},
      function: () => window.getSelection().toString().trim()
    }, (results) => {
      if (results && results[0] && results[0].result && inputText) {
        inputText.value = results[0].result;
      }
    });
  });

  // Init
  populateLangDropdowns();
  restoreLangSelection();
 // inputText.value = sessionStorage.getItem('getSelectionValue');
}

// popup.js
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  chrome.scripting.executeScript(
    {
      target: { tabId: tabs[0].id },
      func: () => sessionStorage.getItem('getSelectionValue'),
    },
    (results) => {
      //inputText.value = sessionStorage.getItem('getSelectionValue');
      inputText.value =
        results && results[0]?.result
          ? results[0].result
          : 'No value found';
    }
  );
});


async function popout(tabId) {
  const activeTab = await getActiveTab()
  window['activeTab'] = activeTab;
  const url = brapi.runtime.getURL("popup.html?tab=" + activeTab.id)
  try {
    if (!tabId) throw "Create"
    const tab = await updateTab(tabId, {url, active: true})
    await updateWindow(tab.windowId, {focused: true}).catch(console.error)
    window.close()
  }
  catch (err) {
    await createWindow({
      url,
      focused: true,
      type: "popup",
      width: 500,
      height: 600,
    })
    window.close()
  }
}

async function init() {
  await domReady()

  $("#btnPlay").click(onPlay);
  $("#btnPause").click(onPause);
  $("#btnStop").click(onStop);
  $("#btnSettings").click(onSettings);
  $("#btnForward").click(onForward);
  $("#btnRewind").click(onRewind);
  $("#decrease-font-size").click(changeFontSize.bind(null, -1));
  $("#increase-font-size").click(changeFontSize.bind(null, +1));
  $("#decrease-window-size").click(changeWindowSize.bind(null, -1));
  $("#increase-window-size").click(changeWindowSize.bind(null, +1));
  $("#toggle-dark-mode").click(toggleDarkMode);

  refreshSize();
  checkAnnouncements();

  const {state} = await bgPageInvoke("getPlaybackState")
  if (state == "PAUSED" || state == "STOPPED") onPlay()
}



function handleError(err) {
  if (!err) return;
  if (err.name == "CancellationException") return;

  if (/^{/.test(err.message)) {
    var errInfo = JSON.parse(err.message);

    $("#status").html(formatError(errInfo)).show();
    $("#status a").click(function() {
      switch ($(this).attr("href")) {
        case "#open-extension-settings":
          brapi.tabs.create({url: "chrome://extensions/?id=" + brapi.runtime.id});
          break;
        case "#request-permissions":
          brapi.permissions.request(errInfo.perms)
            .then(function(granted) {
              if (granted) {
                if (errInfo.reload) return reloadAndPlay()
                else $("#btnPlay").click()
              }
            })
          break;
        case "#sign-in":
          getAuthToken({interactive: true})
            .then(function(token) {
              if (token) $("#btnPlay").click();
            })
            .catch(function(err) {
              $("#status").text(err.message).show();
            })
          break;
        case "#auth-wavenet":
          brapi.permissions.request(config.wavenetPerms)
            .then(function(granted) {
              if (granted) bgPageInvoke("authWavenet");
            })
          break;
        case "#open-pdf-viewer":
          brapi.tabs.create({url: config.pdfViewerUrl})
          break
        case "#connect-phone":
          location.href = "connect-phone.html"
          break
      }
    })
  }
  else if (config.browserId == "opera" && /locked fullscreen/.test(err.message)) {
    $("#status").html("Click <a href='#open-player-tab'>here</a> to start read aloud.").show()
    $("#status a").click(async function() {
      try {
        playerCheckIn$.pipe(rxjs.take(1)).subscribe(() => $("#btnPlay").click())
        const tab = await brapi.tabs.create({
          url: "player.html?opener=popup&autoclose=long",
          index: 0,
          active: false,
        })
        brapi.tabs.update(tab.id, {pinned: true})
          .catch(console.error)
      } catch (err) {
        handleError(err)
      }
    })
  }
  else {
    $("#status").text(err.message).show();
  }
}



rxjs.concat(domReady(), rxjs.interval(500)).subscribe(updateButtons)

async function updateButtons() {
  const [settings, stateInfo] = await Promise.all([
    getSettings(),
    bgPageInvoke("getPlaybackState"),
  ])
  debugger;
 

  const showHighlighting = settings.showHighlighting != null ? Number(settings.showHighlighting) : defaults.showHighlighting
  var state = '';//''.state
  const speech = '';//stateInfo.speechInfo
  var playbackErr ='';// stateInfo.playbackError

  if (playbackErr) handleError(playbackErr)
  piperInitializingSubject.next(!!speech?.isPiper && state == "LOADING")

  $("#imgLoading").toggle(state == "LOADING");
  $("#btnSettings").toggle(state == "STOPPED");
  $("#btnPlay").toggle(state == "PAUSED" || state == "STOPPED");
  $("#btnPause").toggle(state == "PLAYING");
  $("#btnStop").toggle(state == "PAUSED" || state == "PLAYING" || state == "LOADING");
  $("#btnForward, #btnRewind").toggle(state == "PLAYING" || state == "PAUSED");

  if (showHighlighting && (state == "LOADING" || state == "PAUSED" || state == "PLAYING") && speech) {
    $("#highlight, #toolbar").show()
    updateHighlighting(speech)
  }
  else {
    $("#highlight, #toolbar").hide()
  }
}

function updateHighlighting(speech) {
  var elem = $("#highlight");
  if (!elem.data("texts")
    || elem.data("texts").length != speech.texts.length
    || elem.data("texts").some((text,i) => text != speech.texts[i])
  ) {
    elem.css("direction", speech.isRTL ? "rtl" : "")
      .data({texts: speech.texts, position: null})
      .empty()
    for (let i=0; i<speech.texts.length; i++) {
      makeSpan(speech.texts[i])
        .css("cursor", "pointer")
        .click(onSeek.bind(null, i))
        .appendTo(elem)
    }
  }

  const pos = speech.position
  if (!elem.data("position") || positionDiffers(elem.data("position"), pos)) {
    elem.data("position", pos);
    elem.find(".active").removeClass("active");
    const child = elem.children().eq(pos.index)
    const section = pos.word
    if (section) {
      child.empty()
      const text = speech.texts[pos.index]
      let span
      if (section.startIndex > 0) {
        makeSpan(text.slice(0, section.startIndex))
          .appendTo(child)
      }
      if (section.endIndex > section.startIndex) {
        span = makeSpan(text.slice(section.startIndex, section.endIndex))
          .addClass("active")
          .appendTo(child)
      }
      if (text.length > section.endIndex) {
        makeSpan(text.slice(section.endIndex))
          .appendTo(child)
      }
      if (span) scrollIntoView(span, elem)
    }
    else {
      child.addClass("active")
      scrollIntoView(child, elem)
    }
  }
}

function makeSpan(text) {
  const html = escapeHtml(text).replace(/\r?\n/g, "<br/>")
  return $("<span>").html(html)
}

function positionDiffers(left, right) {
  function rangeDiffers(a, b) {
    if (a == null && b == null) return false
    if (a != null && b != null) return a.startIndex != b.startIndex || a.endIndex != b.endIndex
    return true
  }
  return left.index != right.index ||
    rangeDiffers(left.paragraph, right.paragraph) ||
    rangeDiffers(left.sentence, right.sentence) ||
    rangeDiffers(left.word, right.word)
}

function scrollIntoView(child, scrollParent) {
  const childTop = child.offset().top - scrollParent.offset().top
  const childBottom = childTop + child.outerHeight()
  if (childTop < 0 || childBottom >= scrollParent.height())
    scrollParent.animate({scrollTop: scrollParent[0].scrollTop + childTop - 10})
}



var currentPlayRequestId

function onPlay() {
  $("#status").hide();
  const requestId = currentPlayRequestId = Math.random()
  bgPageInvoke("getPlaybackState")
    .then(function(stateInfo) {
      if (stateInfo.state == "PAUSED") return bgPageInvoke("resume")
      else return bgPageInvoke("playTab", queryString.tab ? [Number(queryString.tab)] : [])
    })
    .then(updateButtons)
    .catch(err => {
      if (requestId == currentPlayRequestId) handleError(err)
      else console.debug("Ignoring error from an earlier request", err)
    })
}

function reloadAndPlay() {
  $("#status").hide();
  bgPageInvoke("reloadAndPlayTab", queryString.tab ? [Number(queryString.tab)] : [])
    .then(updateButtons)
    .catch(handleError)
}

function onPause() {
  bgPageInvoke("pause")
    .then(updateButtons)
    .catch(handleError)
}

function onStop() {
  bgPageInvoke("stop")
    .then(updateButtons)
    .catch(handleError)
}

function onSettings() {
  location.href = "options.html?referer=popup.html";
}

function onForward() {
  bgPageInvoke("forward")
    .then(updateButtons)
    .catch(handleError)
}

function onRewind() {
  bgPageInvoke("rewind")
    .then(updateButtons)
    .catch(handleError)
}

function onSeek(n) {
  bgPageInvoke("seek", [n])
    .catch(handleError)
}

function changeFontSize(delta) {
  getSettings(["highlightFontSize"])
    .then(function(settings) {
      var newSize = (settings.highlightFontSize || defaults.hhighlightFontSize) + delta;
      if (newSize >= 1 && newSize <= 8) return updateSettings({highlightFontSize: newSize}).then(refreshSize);
    })
    .catch(handleError)
}

function changeWindowSize(delta) {
  getSettings(["highlightWindowSize"])
    .then(function(settings) {
      var newSize = (settings.highlightWindowSize || defaults.highlightWindowSize) + delta;
      if (newSize >= 1 && newSize <= 3) return updateSettings({highlightWindowSize: newSize}).then(refreshSize);
    })
    .catch(handleError)
}

function refreshSize() {
  return getSettings(["highlightFontSize", "highlightWindowSize"])
    .then(function(settings) {
      var fontSize = getFontSize(settings);
      var windowSize = getWindowSize(settings);
      $("#highlight").css({
        "font-size": fontSize,
      })
      if (queryString.isPopup) $("#highlight").css({
        width: isMobileOS() ? "100%" : windowSize[0],
        height: windowSize[1]
      })
    })
  function getFontSize(settings) {
    switch (settings.highlightFontSize || defaults.highlightFontSize) {
      case 1: return ".9em";
      case 2: return "1em";
      case 3: return "1.1em";
      case 4: return "1.2em";
      case 5: return "1.3em";
      case 6: return "1.4em";
      case 7: return "1.5em";
      default: return "1.6em";
    }
  }
  function getWindowSize(settings) {
    switch (settings.highlightWindowSize || defaults.highlightWindowSize) {
      case 1: return [430, 330];
      case 2: return [550, 420];
      default: return [750, 450];
    }
  }
}

function checkAnnouncements() {
  var now = new Date().getTime();
  getSettings(["announcement"])
    .then(function(settings) {
      var ann = settings.announcement;
      if (ann && ann.expire > now)
        return ann;
      else
        return ajaxGet(config.serviceUrl + "/read-aloud/announcement")
          .then(JSON.parse)
          .then(function(result) {
            result.expire = now + 6*3600*1000;
            if (ann && result.id == ann.id) {
              result.lastShown = ann.lastShown;
              result.disabled = ann.disabled;
            }
            updateSettings({announcement: result});
            return result;
          })
    })
    .then(function(ann) {
      if (ann.text && !ann.disabled) {
        if (!ann.lastShown || now-ann.lastShown > ann.period*60*1000) {
          showAnnouncement(ann);
          ann.lastShown = now;
          updateSettings({announcement: ann});
        }
      }
    })
}

function showAnnouncement(ann) {
  var html = escapeHtml(ann.text).replace(/\[(.*?)\]/g, "<a target='_blank' href='" + ann.link + "'>$1</a>").replace(/\n/g, "<br/>");
  $("#footer").html(html).addClass("announcement");
  if (ann.disableIfClick)
    $("#footer a").click(function() {
      ann.disabled = true;
      updateSettings({announcement: ann});
    })
}

function toggleDarkMode() {
  const darkMode = document.body.classList.toggle("dark-mode")
  updateSettings({darkMode})
}