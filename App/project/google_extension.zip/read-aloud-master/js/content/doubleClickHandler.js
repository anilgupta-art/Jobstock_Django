// doubleClickHandler.js
// Enhanced with drag-and-drop functionality for both popup and icon

// Add this function to create and manage the extension icon
function createExtensionIcon(targetLanguage = 'Hindi') {
  // Remove existing icon if any
  let originaldata=''
  const existingIcon = document.getElementById('translation-extension-icon');
  if (existingIcon) existingIcon.remove();

  const icon = document.createElement('div');
  icon.id = 'translation-extension-icon';
  icon.innerHTML = '🔊'; // Speaker icon
  icon.style.position = 'absolute';
  icon.style.zIndex = '2147483646'; // Just below popup
  icon.style.cursor = 'grab';
  icon.style.padding = '8px';
  icon.style.backgroundColor = '#4285f4';
  icon.style.color = 'white';
  icon.style.borderRadius = '50%';
  icon.style.boxShadow = '0 2px 10px rgba(0,0,0,0.3)';
  icon.style.fontSize = '16px';
  icon.style.userSelect = 'none';
  icon.style.transition = 'all 0.3s ease';

  // Add hover effects
  icon.addEventListener('mouseenter', () => {
    if (!icon.classList.contains('dragging')) {
      icon.style.transform = 'scale(1.1)';
      icon.style.backgroundColor = '#3367d6';
    }
  });

  icon.addEventListener('mouseleave', () => {
    if (!icon.classList.contains('dragging')) {
      icon.style.transform = 'scale(1)';
      icon.style.backgroundColor = '#4285f4';
    }
  });

  // Position icon near the target language indicator
  const languageIndicator = document.querySelector('span[style*="background: #6c757d"]');
  if (languageIndicator) {
    const rect = languageIndicator.getBoundingClientRect();
    icon.style.top = `${rect.top + window.scrollY - 5}px`;
    icon.style.left = `${rect.right + window.scrollX + 10}px`;
  }

  // Click handler to open pop.html
  icon.addEventListener('click', (e) => {
    // Only trigger click if not dragging
    if (!icon.classList.contains('dragging')) {
      e.stopPropagation();
      openPopupWindow(targetLanguage);
    }
  });

  document.body.appendChild(icon);
  return icon;
}

// Make both elements draggable together
function makeDraggableTogether(popup, icon) {
  let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
  let isDragging = false;
  let dragOffsetX = 0, dragOffsetY = 0;
  
  // Create drag handle (header area) for popup
  const header = popup.querySelector('div[style*="display: flex; justify-content: space-between; align-items: center;"]');
  
  // Function to start dragging
  function startDrag(e) {
    // Only start dragging on left click
    if (e.button !== 0) return;
    
    e.preventDefault();
    isDragging = true;
    
    // Get the initial mouse cursor position
    pos3 = e.clientX;
    pos4 = e.clientY;
    
    // Calculate initial offset between popup and icon
    const popupRect = popup.getBoundingClientRect();
    const iconRect = icon.getBoundingClientRect();
    dragOffsetX = iconRect.left - popupRect.left;
    dragOffsetY = iconRect.top - popupRect.top;
    
    document.addEventListener('mouseup', stopDrag);
    document.addEventListener('mousemove', drag);
    
    // Add dragging class for visual feedback
    popup.classList.add('dragging');
    icon.classList.add('dragging');
    icon.style.cursor = 'grabbing';
  }

  function drag(e) {
    if (!isDragging) return;
    
    e.preventDefault();
    
    // Calculate the new cursor position
    pos1 = pos3 - e.clientX;
    pos2 = pos4 - e.clientY;
    pos3 = e.clientX;
    pos4 = e.clientY;
    
    // Set the popup's new position
    const popupNewTop = popup.offsetTop - pos2;
    const popupNewLeft = popup.offsetLeft - pos1;
    
    // Keep popup within viewport bounds
    const maxTop = window.innerHeight - popup.offsetHeight;
    const maxLeft = window.innerWidth - popup.offsetWidth;
    
    const finalPopupTop = Math.max(0, Math.min(popupNewTop, maxTop));
    const finalPopupLeft = Math.max(0, Math.min(popupNewLeft, maxLeft));
    
    popup.style.top = finalPopupTop + "px";
    popup.style.left = finalPopupLeft + "px";
    
    // Move icon relative to popup position
    const iconNewTop = finalPopupTop + dragOffsetY;
    const iconNewLeft = finalPopupLeft + dragOffsetX;
    
    // Keep icon within viewport bounds
    const iconMaxTop = window.innerHeight - icon.offsetHeight;
    const iconMaxLeft = window.innerWidth - icon.offsetWidth;
    
    icon.style.top = Math.max(0, Math.min(iconNewTop, iconMaxTop)) + "px";
    icon.style.left = Math.max(0, Math.min(iconNewLeft, iconMaxLeft)) + "px";
  }

  function stopDrag() {
    isDragging = false;
    
    // Stop moving when mouse button is released
    document.removeEventListener('mouseup', stopDrag);
    document.removeEventListener('mousemove', drag);
    
    // Remove dragging class
    popup.classList.remove('dragging');
    icon.classList.remove('dragging');
    icon.style.cursor = 'grab';
    
    // Restore hover effects
    icon.style.transform = 'scale(1)';
    icon.style.backgroundColor = '#4285f4';
  }

  // Set up drag handles
  if (header) {
    header.style.cursor = 'grab';
    header.addEventListener('mousedown', startDrag);
    
    header.addEventListener('mouseenter', () => {
      if (!isDragging) {
        header.style.cursor = 'grab';
      }
    });
    
    header.addEventListener('mouseleave', () => {
      if (!isDragging) {
        header.style.cursor = 'default';
      }
    });
  } else {
    // Fallback: make entire popup draggable
    popup.style.cursor = 'grab';
    popup.addEventListener('mousedown', startDrag);
  }

  // Also make icon draggable (but only moves both together)
  icon.addEventListener('mousedown', startDrag);
}

// Function to open pop.html in a new window/popup
async function openPopupWindow(targetLanguage) {
  const sessionId = Date.now();
  const width = 400;
  const height = 500;
  const left = (screen.width - width) / 2;
  const top = (screen.height - height) / 2;
   
  const url = chrome.runtime.getURL("popup.html");//?text="+encodeURIComponent(originaldata)+"&lang="+encodeURIComponent(targetLanguage)+"&sessionId=" + sessionId);
  chrome.runtime.sendMessage({
    action: "openPopup",
    url: url,
    options: {
      url: url,
      type: 'popup',
      width: width,
      height: height,
      left: Math.max(0, left),
      top: Math.max(0, top)
    }
  });
}

// Modified showPopup function to include drag-and-drop functionality for both elements
async function showPopup(content, range, targetLanguage = 'Hindi') {
  // Remove existing popup if any
  const existingPopup = document.getElementById('translation-popup');
  if (existingPopup) existingPopup.remove();

  const popup = document.createElement('div');
  popup.id = 'translation-popup';
  popup.style.position = 'absolute';
  popup.style.backgroundColor = '#f8f9fa';
  popup.style.border = '1px solid #dee2e6';
  popup.style.padding = '12px';
  popup.style.borderRadius = '6px';
  popup.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
  popup.style.zIndex = '2147483647'; // Maximum z-index
  popup.style.maxWidth = '350px';
  popup.style.fontSize = '14px';
  popup.style.fontFamily = 'Arial, sans-serif';
  popup.style.cursor = 'default';

  // Position near selection
  const rect = range.getBoundingClientRect();
  popup.style.top = `${rect.bottom + window.scrollY + 5}px`;
  popup.style.left = `${Math.max(10, rect.left + window.scrollX - 50)}px`;

  // Determine text direction based on language
  const isRTL = ['ar', 'he', 'fa', 'ur'].includes(content.targetLanguageCode || 'hi');
  const translationDirection = isRTL ? 'rtl' : 'ltr';
  let languageCode = await chrome.storage.local.get(['sourceLang', 'destLang']);
  
  targetLanguage = getlanguage(languageCode.destLang);
  let sourceLanguage = getlanguage(languageCode.sourceLang);

  // Popup content with language information
  popup.innerHTML = `
    <div style="margin-bottom: 8px; color: #495057;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; user-select: none;">
        <strong style="font-size: 16px;">Translation</strong>
        <span style="background: #6c757d; color: white; padding: 2px 8px; border-radius: 12px; font-size: 12px;">
          Drag to move
        </span>
      </div>
      
      <div style="margin-bottom: 8px;">
        <strong>Original:${sourceLanguage}:</strong>
        <div style="color: #212529; margin: 4px 0 8px 0; padding: 8px; background: #fff; border-radius: 4px; border: 1px solid #e9ecef;">
          ${content.originalText}
        </div>
      </div>
      
      <div style="margin-bottom: 12px;">
        <strong>Translated:${targetLanguage}</strong>
        <div style="color: #212529; margin: 4px 0 8px 0; padding: 8px; background: #fff; border-radius: 4px; border: 1px solid #e9ecef; direction: ${translationDirection}; text-align: ${isRTL ? 'right' : 'left'};">
          ${content.translatedText}
        </div>
      </div>
    </div>
    <div style="display: flex; gap: 8px; flex-wrap: wrap;">
      <button class="popup-btn speak-original" style="padding: 6px 12px; background: #28a745; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 12px;">
        🔊 Speak ${sourceLanguage}
      </button>
      <button class="popup-btn speak-translation" style="padding: 6px 12px; background: #17a2b8; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 12px;">
        🔊 Speak ${targetLanguage}
      </button>
      <button class="popup-btn copy-translation" style="padding: 6px 12px; background: #6c757d; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 12px;">
        📋 Copy
      </button>
    </div>
  `;

  document.body.appendChild(popup);

  // Create extension icon
  const icon = createExtensionIcon(targetLanguage);

  // Make both elements draggable together
  makeDraggableTogether(popup, icon);

  // Add button functionality
  addPopupButtonFunctionality(popup, content, targetLanguage);

  // Auto-remove icon when popup is closed
  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      if (mutation.removedNodes.length > 0) {
        const removed = Array.from(mutation.removedNodes).some(node => 
          node.id === 'translation-popup'
        );
        if (removed) {
          icon.remove();
          observer.disconnect();
        }
      }
    });
  });

  observer.observe(document.body, { childList: true });

  // Close popup when clicking outside
  setupPopupCloseHandlers(popup, icon);

  return { popup, icon };
}

// Add functionality to popup buttons
function addPopupButtonFunctionality(popup, content, targetLanguage) {
  // Speak original text
  const speakOriginalBtn = popup.querySelector('.speak-original');
  if (speakOriginalBtn) {
    speakOriginalBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      chrome.runtime.sendMessage({
        method: "playSelectedText",
        text: content.originalText,
        lang: 'en'
      });
    });
  }

  // Speak translated text
  const speakTranslationBtn = popup.querySelector('.speak-translation');
  if (speakTranslationBtn) {
    speakTranslationBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      chrome.runtime.sendMessage({
        method: "playSelectedText",
        text: content.translatedText,
        lang: content.targetLanguageCode || 'hi'
      });
    });
  }

  // Copy translated text
  const copyTranslationBtn = popup.querySelector('.copy-translation');
  if (copyTranslationBtn) {
    copyTranslationBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      navigator.clipboard.writeText(content.translatedText).then(() => {
        const btn = e.target;
        const originalText = btn.textContent;
        btn.textContent = '✅ Copied!';
        btn.style.background = '#28a745';
        setTimeout(() => {
          btn.textContent = originalText;
          btn.style.background = '#6c757d';
        }, 2000);
      }).catch(err => {
        console.error('Failed to copy text: ', err);
      });
    });
  }
}

// Modified setupPopupCloseHandlers to handle both elements
function setupPopupCloseHandlers(popup, icon) {
  let closeHandler;
  
  // Close popup when clicking outside
  closeHandler = function(e) {
    if (!popup.contains(e.target) && !icon.contains(e.target)) {
      popup.remove();
      icon.remove();
      document.removeEventListener('click', closeHandler);
    }
  };
  
  setTimeout(() => {
    document.addEventListener('click', closeHandler);
  }, 100);

  // Close popup on Escape key
  const escapeHandler = function(e) {
    if (e.key === 'Escape') {
      popup.remove();
      icon.remove();
      document.removeEventListener('keydown', escapeHandler);
    }
  };
  
  document.addEventListener('keydown', escapeHandler);
}

// Function to get language name from code
function getLanguageName(languageCode) {
  const languageMap = {
    'hi': 'Hindi',
    'es': 'Spanish',
    'fr': 'French',
    'de': 'German',
    'ja': 'Japanese',
    'zh': 'Chinese',
    'ar': 'Arabic',
    'ru': 'Russian',
    'pt': 'Portuguese',
    'it': 'Italian'
  };
  return languageMap[languageCode] || 'Translation';
}

// Function to show loading popup
function showLoadingPopup(selectedText, range, targetLanguage = 'Hindi') {
  originaldata=selectedText;
  showPopup({
    originalText: selectedText,
    translatedText: 'Translating... ⏳',
    targetLanguageCode: 'text'
  }, range, targetLanguage);
}

// Double-click handler for text selection and translation
function setupDoubleClickHandler() {
  document.addEventListener('mouseup', async function(event) {
    // Check if the click was on a button in our popup or icon
    const popup = document.getElementById('translation-popup');
    const icon = document.getElementById('translation-extension-icon');
    
    if ((popup && popup.contains(event.target)) || 
        (icon && (icon === event.target || icon.contains(event.target)))) {
      return; // Don't process selection if clicking on popup buttons or icon
    }
    
    let selection = window.getSelection();
    let getSelectionValue = selection.toString().trim();
    if (selection && selection.toString().trim()) {
      let selectedText = selection.toString();
      sessionStorage.removeItem('getSelectionValue');
      sessionStorage.setItem('getSelectionValue',selectedText);
     // window["getSelectionValue"] = window.getSelection().toString().trim();
      
      // Check if this is a translation request (from context menu)
      const translationRequest = sessionStorage.getItem('translationRequest');
      
      if (translationRequest) {
        const { language, languageName } = JSON.parse(translationRequest);
        sessionStorage.removeItem('translationRequest');
        
        // Show loading popup immediately
        showLoadingPopup(selectedText, selection.getRangeAt(0), languageName);
        
        // Send to background for processing with specific language
        chrome.runtime.sendMessage({
          method: "processSelectedText",
          text: selectedText,
          language: language
        }, (response) => {
          if (response && !response.error) {
            showPopup({
              originalText: selectedText,
              translatedText: response.translatedText,
              targetLanguageCode: window.SUPPORTED_LANGUAGES?.[response.targetLanguage]?.target || 'hi'
            }, selection.getRangeAt(0), getLanguageName(window.SUPPORTED_LANGUAGES?.[response.targetLanguage]?.target || 'hi'));
          } else if (response && response.error) {
            showPopup({
              originalText: selectedText,
              translatedText: '❌ Translation failed: ' + response.error,
              targetLanguageCode: 'hi'
            }, selection.getRangeAt(0), languageName);
          }
        });
      } else {
        // Default behavior - show loading and use default language
        showLoadingPopup(selectedText, selection.getRangeAt(0));
        
        // Send to background for processing with default language
        chrome.runtime.sendMessage({
          method: "processSelectedText",
          text: selectedText,
          sourceLanguage: 'hindi',
          targetLanguage: 'english'
        }, (response) => {
          if (response && !response.error) {
            showPopup({
              originalText: selectedText,
              translatedText: response.translatedText,
              targetLanguageCode: window.SUPPORTED_LANGUAGES?.[response.targetLanguage]?.target || 'hi'
            }, selection.getRangeAt(0), getLanguageName(window.SUPPORTED_LANGUAGES?.[response.targetLanguage]?.target || 'hi'));
          } else if (response && response.error) {
            showPopup({
              originalText: selectedText,
              translatedText: '❌ Translation failed: ' + response.error,
              targetLanguageCode: 'hi'
            }, selection.getRangeAt(0), 'Hindi');
          }
        });
      }
    }
  });
}

// Listen for messages from background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  originaldata=request.originalText;
  if (request.action === "showTranslation") {
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      showPopup({
        originalText: request.originalText,
        translatedText: request.translatedText,
        targetLanguageCode: Object.keys(window.SUPPORTED_LANGUAGES || {}).find(key => 
          window.SUPPORTED_LANGUAGES[key].name === request.targetLanguage
        )?.target || 'hi'
      }, selection.getRangeAt(0), request.targetLanguage || 'Hindi');
    }
    sendResponse({ success: true });
  }
  
  if (request.action === "prepareTranslation") {
    // Store translation request for next selection
    sessionStorage.setItem('translationRequest', JSON.stringify({
      language: request.language,
      languageName: request.languageName
    }));
    sendResponse({ success: true });
  }
  
  if (request.action === "openPopupWindow") {
    openPopupWindow(request.targetLanguage);
    sendResponse({ success: true });
  }
  
  return true;
});

// Add styles for better popup and icon appearance
function addPopupStyles() {
  const style = document.createElement('style');
  style.textContent = `
    #translation-popup {
      animation: popupFadeIn 0.2s ease-out;
      transition: box-shadow 0.2s ease;
    }
    
    #translation-popup.dragging {
      box-shadow: 0 8px 25px rgba(0,0,0,0.2);
      cursor: grabbing !important;
    }
    
    #translation-extension-icon {
      animation: iconBounce 0.5s ease-out;
      transition: all 0.3s ease;
    }
    
    #translation-extension-icon.dragging {
      transform: scale(1.1) !important;
      cursor: grabbing !important;
      box-shadow: 0 4px 15px rgba(0,0,0,0.4);
    }
    
    @keyframes popupFadeIn {
      from {
        opacity: 0;
        transform: translateY(-10px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    
    @keyframes iconBounce {
      0% {
        transform: scale(0);
      }
      50% {
        transform: scale(1.2);
      }
      100% {
        transform: scale(1);
      }
    }
    
    .popup-btn:hover {
      opacity: 0.9;
      transform: translateY(-1px);
      transition: all 0.2s ease;
    }
    
    .popup-btn:active {
      transform: translateY(0);
    }
    
    #translation-extension-icon:hover:not(.dragging) {
      transform: scale(1.1) !important;
    }
  `;
  document.head.appendChild(style);
}

async function getlanguagecode() {
    const result = await chrome.storage.local.get(['sourceLang', 'destLang']);
    return result;
}

function getlanguage(code) {
    const languages = window.SUPPORTED_LANGUAGES || {};
   for (const key in languages) {
        if (languages[key].code === code) {
            return languages[key].name;
        }
    }
    return 'Unknown';
}

// Initialize the double click handler
function initDoubleClickHandler() {
  // Add styles first
  addPopupStyles();
  
  // Setup double click handler
  setupDoubleClickHandler();
  
  // Make SUPPORTED_LANGUAGES available globally if not already defined
  if (typeof window.SUPPORTED_LANGUAGES === 'undefined') {
    // Try to get from background script or use default
    chrome.runtime.sendMessage({action: "getSupportedLanguages"}, (response) => {
      if (response && response.languages) {
        window.SUPPORTED_LANGUAGES = response.languages;
      } 
    });
  }
}

// Initialize when the script loads
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initDoubleClickHandler);
} else {
  initDoubleClickHandler();
}