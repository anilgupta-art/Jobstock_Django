(function() {
  'use strict';
  console.log('Loading MultiLanguageTranslator...');

  // Configuration for supported languages with source and target support
  const SUPPORTED_LANGUAGES = {
    'auto': { code: 'auto', name: 'Auto Detect', source: true, target: false },
    'english': { code: 'en', name: 'English', source: true, target: true },
    'hindi': { code: 'hi', name: 'Hindi', source: true, target: true },
    'spanish': { code: 'es', name: 'Spanish', source: true, target: true },
    'french': { code: 'fr', name: 'French', source: true, target: true },
    'german': { code: 'de', name: 'German', source: true, target: true },
    'japanese': { code: 'ja', name: 'Japanese', source: true, target: true },
    'chinese': { code: 'zh', name: 'Chinese', source: true, target: true },
    'arabic': { code: 'ar', name: 'Arabic', source: true, target: true },
    'russian': { code: 'ru', name: 'Russian', source: true, target: true },
    'portuguese': { code: 'pt', name: 'Portuguese', source: true, target: true },
    'italian': { code: 'it', name: 'Italian', source: true, target: true },
    'korean': { code: 'ko', name: 'Korean', source: true, target: true },
    'dutch': { code: 'nl', name: 'Dutch', source: true, target: true },
    'turkish': { code: 'tr', name: 'Turkish', source: true, target: true },
    'greek': { code: 'el', name: 'Greek', source: true, target: true },
    'hebrew': { code: 'he', name: 'Hebrew', source: true, target: true },
    'thai': { code: 'th', name: 'Thai', source: true, target: true },
    'vietnamese': { code: 'vi', name: 'Vietnamese', source: true, target: true },
    'indonesian': { code: 'id', name: 'Indonesian', source: true, target: true },
    'malay': { code: 'ms', name: 'Malay', source: true, target: true },
    'filipino': { code: 'tl', name: 'Filipino', source: true, target: true },
    'swedish': { code: 'sv', name: 'Swedish', source: true, target: true },
    'norwegian': { code: 'no', name: 'Norwegian', source: true, target: true },
    'danish': { code: 'da', name: 'Danish', source: true, target: true },
    'finnish': { code: 'fi', name: 'Finnish', source: true, target: true },
    'polish': { code: 'pl', name: 'Polish', source: true, target: true },
    'ukrainian': { code: 'uk', name: 'Ukrainian', source: true, target: true },
    'czech': { code: 'cs', name: 'Czech', source: true, target: true },
    'romanian': { code: 'ro', name: 'Romanian', source: true, target: true },
    'hungarian': { code: 'hu', name: 'Hungarian', source: true, target: true },
    'bulgarian': { code: 'bg', name: 'Bulgarian', source: true, target: true },
    'catalan': { code: 'ca', name: 'Catalan', source: true, target: true },
    'croatian': { code: 'hr', name: 'Croatian', source: true, target: true },
    'serbian': { code: 'sr', name: 'Serbian', source: true, target: true },
    'slovak': { code: 'sk', name: 'Slovak', source: true, target: true },
    'slovenian': { code: 'sl', name: 'Slovenian', source: true, target: true },
    'lithuanian': { code: 'lt', name: 'Lithuanian', source: true, target: true },
    'latvian': { code: 'lv', name: 'Latvian', source: true, target: true },
    'estonian': { code: 'et', name: 'Estonian', source: true, target: true },
    'maltese': { code: 'mt', name: 'Maltese', source: true, target: true },
    'afrikaans': { code: 'af', name: 'Afrikaans', source: true, target: true },
    'swahili': { code: 'sw', name: 'Swahili', source: true, target: true },
    'irish': { code: 'ga', name: 'Irish', source: true, target: true },
    'scottish gaelic': { code: 'gd', name: 'Scottish Gaelic', source: true, target: true },
    'welsh': { code: 'cy', name: 'Welsh', source: true, target: true },
    'basque': { code: 'eu', name: 'Basque', source: true, target: true },
    'galician': { code: 'gl', name: 'Galician', source: true, target: true },
    'icelandic': { code: 'is', name: 'Icelandic', source: true, target: true },
    'albanian': { code: 'sq', name: 'Albanian', source: true, target: true },
    'armenian': { code: 'hy', name: 'Armenian', source: true, target: true },
    'azerbaijani': { code: 'az', name: 'Azerbaijani', source: true, target: true },
    'belarusian': { code: 'be', name: 'Belarusian', source: true, target: true },
    'bosnian': { code: 'bs', name: 'Bosnian', source: true, target: true },
    'esperanto': { code: 'eo', name: 'Esperanto', source: true, target: true },
    'georgian': { code: 'ka', name: 'Georgian', source: true, target: true },
    'haitian creole': { code: 'ht', name: 'Haitian Creole', source: true, target: true },
    'hawaiian': { code: 'haw', name: 'Hawaiian', source: true, target: true },
    'javanese': { code: 'jv', name: 'Javanese', source: true, target: true },
    'kannada': { code: 'kn', name: 'Kannada', source: true, target: true },
    'kazakh': { code: 'kk', name: 'Kazakh', source: true, target: true },
    'khmer': { code: 'km', name: 'Khmer', source: true, target: true },
    'lao': { code: 'lo', name: 'Lao', source: true, target: true },
    'latin': { code: 'la', name: 'Latin', source: true, target: true },
    'macedonian': { code: 'mk', name: 'Macedonian', source: true, target: true },
    'malagasy': { code: 'mg', name: 'Malagasy', source: true, target: true },
    'marathi': { code: 'mr', name: 'Marathi', source: true, target: true },
    'mongolian': { code: 'mn', name: 'Mongolian', source: true, target: true },
    'burmese': { code: 'my', name: 'Burmese', source: true, target: true },
    'nepali': { code: 'ne', name: 'Nepali', source: true, target: true },
    'pashto': { code: 'ps', name: 'Pashto', source: true, target: true },
    'persian': { code: 'fa', name: 'Persian', source: true, target: true },
    'punjabi': { code: 'pa', name: 'Punjabi', source: true, target: true },
    'samoan': { code: 'sm', name: 'Samoan', source: true, target: true },
    'sindhi': { code: 'sd', name: 'Sindhi', source: true, target: true },
    'sinhala': { code: 'si', name: 'Sinhala', source: true, target: true },
    'somali': { code: 'so', name: 'Somali', source: true, target: true },
    'sundanese': { code: 'su', name: 'Sundanese', source: true, target: true },
    'tajik': { code: 'tg', name: 'Tajik', source: true, target: true },
    'tamil': { code: 'ta', name: 'Tamil', source: true, target: true },
    'telugu': { code: 'te', name: 'Telugu', source: true, target: true },
    'urdu': { code: 'ur', name: 'Urdu', source: true, target: true },
    'uyghur': { code: 'ug', name: 'Uyghur', source: true, target: true },
    'uzbek': { code: 'uz', name: 'Uzbek', source: true, target: true },
    'yiddish': { code: 'yi', name: 'Yiddish', source: true, target: true },
    'yoruba': { code: 'yo', name: 'Yoruba', source: true, target: true },
    'zulu': { code: 'zu', name: 'Zulu', source: true, target: true }
  };

  const DEFAULT_SOURCE_LANGUAGE = 'auto';
  const DEFAULT_TARGET_LANGUAGE = 'hindi';

  function MultiLanguageTranslator() {
    this.apis = [
      this.myMemoryTranslate.bind(this),
      this.googleTranslateFallback.bind(this),
      this.libretranslateFallback.bind(this)
    ];
    this.sourceLanguage = DEFAULT_SOURCE_LANGUAGE;
    this.targetLanguage = DEFAULT_TARGET_LANGUAGE;
  }

  MultiLanguageTranslator.prototype.setSourceLanguage = function(language) {
    if (SUPPORTED_LANGUAGES[language] && SUPPORTED_LANGUAGES[language].source) {
      this.sourceLanguage = language;
      return true;
    }
    return false;
  };

  MultiLanguageTranslator.prototype.setTargetLanguage = function(language) {
    if (SUPPORTED_LANGUAGES[language] && SUPPORTED_LANGUAGES[language].target) {
      this.targetLanguage = language;
      return true;
    }
    return false;
  };

  MultiLanguageTranslator.prototype.getSourceLanguage = function() {
    return this.sourceLanguage;
  };

  MultiLanguageTranslator.prototype.getTargetLanguage = function() {
    return this.targetLanguage;
  };

  MultiLanguageTranslator.prototype.getSupportedLanguages = function() {
    return SUPPORTED_LANGUAGES;
  };

  MultiLanguageTranslator.prototype.translate = function(text, sourceLanguage, targetLanguage) {
    var self = this;
    var sourceLang = sourceLanguage || this.sourceLanguage;
    var targetLang = targetLanguage || this.targetLanguage;
    
    var sourceLangCode = SUPPORTED_LANGUAGES[sourceLang] ? 
      (sourceLang === 'auto' ? 'auto' : SUPPORTED_LANGUAGES[sourceLang].code) : 
      SUPPORTED_LANGUAGES[DEFAULT_SOURCE_LANGUAGE].code;
      
    var targetLangCode = SUPPORTED_LANGUAGES[targetLang] ? 
      SUPPORTED_LANGUAGES[targetLang].code : 
      SUPPORTED_LANGUAGES[DEFAULT_TARGET_LANGUAGE].code;


      
chrome.storage.local.get(['sourceLang', 'destLang', ], function(result) { 
    console.log('Source language:', result.sourceLang);
    console.log('Target language:', result.destLang);

    targetLangCode = result.destLang || targetLangCode;
    sourceLangCode = result.sourceLang || sourceLangCode;
    
});

    return new Promise(function(resolve, reject) {
      if (!text || typeof text !== 'string' || text.trim() === '') {
        resolve(text);
        return;
      }

      var tryApi = function(index) {
        if (index >= self.apis.length) {
          reject(new Error('All translation APIs failed'));
          return;
        }

        self.apis[index](text, sourceLangCode, targetLangCode)
          .then(function(result) {
            if (result && result !== text) {
              resolve(result);
            } else {
              tryApi(index + 1);
            }
          })
          .catch(function(error) {
            console.warn('Translation API failed:', error);
            tryApi(index + 1);
          });
      };

      tryApi(0);
    });
  };

  MultiLanguageTranslator.prototype.myMemoryTranslate = function(text, sourceLang, targetLang) {
    // Auto detection not supported by MyMemory, default to English
    const sourceCode = sourceLang === 'auto' ? 'en' : sourceLang;
    return fetch(
      'https://api.mymemory.translated.net/get?q=' + encodeURIComponent(text) + '&langpair=' + sourceCode + '|' + targetLang
    )
    .then(r => {
      if (!r.ok) throw new Error('MyMemory API error: ' + r.status);
      return r.json();
    })
    .then(d => d.responseData.translatedText);
  };

  MultiLanguageTranslator.prototype.googleTranslateFallback = function(text, sourceLang, targetLang) {
    return fetch(
      'https://translate.googleapis.com/translate_a/single?client=gtx&sl=' + sourceLang + '&tl=' + targetLang + '&dt=t&q=' + encodeURIComponent(text)
    )
    .then(r => {
      if (!r.ok) throw new Error('Google Translate API error: ' + r.status);
      return r.json();
    })
    .then(d => d[0][0][0]);
  };

  MultiLanguageTranslator.prototype.libretranslateFallback = function(text, sourceLang, targetLang) {
    // Auto detection not supported by LibreTranslate, default to English
    const sourceCode = sourceLang === 'auto' ? 'en' : sourceLang;
    return fetch('https://libretranslate.com/translate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify({ 
        q: text, 
        source: sourceCode, 
        target: targetLang, 
        format: 'text' 
      })
    })
    .then(r => {
      if (!r.ok) throw new Error('LibreTranslate API error: ' + r.status);
      return r.json();
    })
    .then(d => d.translatedText);
  };

  // ✅ Expose globally
  if (typeof window !== 'undefined') {
    window.MultiLanguageTranslator = MultiLanguageTranslator;
    window.SUPPORTED_LANGUAGES = SUPPORTED_LANGUAGES;
  } else if (typeof self !== 'undefined') { 
    self.MultiLanguageTranslator = MultiLanguageTranslator;
    self.SUPPORTED_LANGUAGES = SUPPORTED_LANGUAGES;
  }

  console.log('MultiLanguageTranslator loaded successfully');
})();

// Extension installation handler
if (typeof brapi !== 'undefined' && brapi.runtime && brapi.runtime.onInstalled) {
  brapi.runtime.onInstalled.addListener(function() {
    installContentScripts();
    installContextMenus();
    installTranslationContextMenu();
  });
}

/**
 * IPC handlers
 */
var handlers = {
  playText: playText,
  playTab: playTab,
  reloadAndPlayTab: reloadAndPlayTab,
  stop: stop,
  pause: pause,
  resume: resume,
  getPlaybackState: getPlaybackState,
  forward: forward,
  rewind: rewind,
  seek: seek,
  reportIssue: reportIssue,
  authWavenet: authWavenet,
  managePiperVoices: managePiperVoices,
  translateText: async function(text, sourceLang, targetLang) {
    try {
      if (!window.MultiLangTranslator) throw new Error("MultiLangTranslator not loaded");
      const translator = new window.MultiLangTranslator();
      // Validate language codes using shared.js
      const src = window.LanguageUtils.isValidSourceLanguage(sourceLang) ? sourceLang : 'en';
      const tgt = window.LanguageUtils.isValidTargetLanguage(targetLang) ? targetLang : 'hi';
      const result = await translator.translate(text, src, tgt);
      return { translatedText: result, sourceLang: src, targetLang: tgt };
    } catch (err) {
      return { error: err.message };
    }
  }
};

// Register message listener if brapi is available
if (typeof brapi !== 'undefined' && brapi.runtime && brapi.runtime.onMessage) {
  registerMessageListener("serviceWorker", handlers);
}

/**
 * Installers
 */
async function installContentScripts() {
  if (typeof brapi === 'undefined' || !brapi.scripting) return;
  
  const scripts = [
    {
      matches: ["https://docs.google.com/document/*"],
      id: "google-docs",
      js: ["js/page/google-doc.js"],
      runAt: "document_start",
      world: "MAIN"
    },
  ];
  
  try {
    const registeredIds = await brapi.scripting.getRegisteredContentScripts({ids: scripts.map(x => x.id)})
      .then(scripts => scripts.map(x => x.id))
      .catch(err => {
        console.error(err);
        return [];
      });
    
    if (registeredIds.length) {
      console.info("Already registered content scripts", registeredIds);
    }
    
    const scriptsToRegister = scripts.filter(script => !registeredIds.includes(script.id));
    for (const script of scriptsToRegister) {
      await brapi.scripting.registerContentScripts([script])
        .then(() => console.info("Successfully registered content script", script.id))
        .catch(err => console.error("Failed to register content script", script.id, err));
    }
  } catch (error) {
    console.error("Error installing content scripts:", error);
  }
}

function installContextMenus() {
  if (typeof brapi === 'undefined' || !brapi.contextMenus) return;
  
  brapi.contextMenus.create({
    id: "read-selection",
    title: brapi.i18n.getMessage("context_read_selection"),
    contexts: ["selection"]
  }, function() {
    if (brapi.runtime.lastError) console.error(brapi.runtime.lastError);
    else console.info("Installed context menus");
  });
}

function installTranslationContextMenu() {
  if (typeof brapi === 'undefined' || !brapi.contextMenus) return;

  // Remove existing translation menus first
  brapi.contextMenus.removeAll(function() {
    // Create read selection menu
    brapi.contextMenus.create({
      id: "read-selection",
      title: brapi.i18n.getMessage("context_read_selection") || "Read selection",
      contexts: ["selection"]
    });

    // Create parent translation menu
    brapi.contextMenus.create({
      id: "translateText",
      title: "Translate to",
      contexts: ["selection"]
    });

    // Create submenus for each language
    Object.entries(SUPPORTED_LANGUAGES).forEach(([key, lang]) => {
      if (lang.target) {
        brapi.contextMenus.create({
          id: `translateTo_${key}`,
          parentId: "translateText",
          title: lang.name,
          contexts: ["selection"]
        });
      }
    });
  });
}

/**
 * Context menu handlers
 */
if (typeof brapi !== 'undefined' && brapi.contextMenus && brapi.contextMenus.onClicked) {
  brapi.contextMenus.onClicked.addListener(function(info, tab) {
    if (info.menuItemId === "read-selection") {
      Promise.resolve()
        .then(function() {
          if (tab && tab.id != -1) return detectTabLanguage(tab.id);
          else return undefined;
        })
        .then(function(lang) {
          return playText(info.selectionText, {lang: lang});
        })
        .catch(handleHeadlessError);
    }
    else if (info.menuItemId.startsWith("translateTo_")) {
      const languageKey = info.menuItemId.replace("translateTo_", "");
      if (info.selectionText && SUPPORTED_LANGUAGES[languageKey]) {
        translateAndPlaySelection(info.selectionText, tab, languageKey)
          .catch(handleHeadlessError);
      }
    }
  });
}

/**
 * Shortcut keys handlers
 */
if (typeof brapi !== 'undefined' && brapi.commands && brapi.commands.onCommand) {
  brapi.commands.onCommand.addListener(function(command) {
    if (command === "play") {
      getPlaybackState()
        .then(function(stateInfo) {
          switch (stateInfo.state) {
            case "PLAYING": return pause();
            case "PAUSED": return resume();
            case "STOPPED": return playTab();
          }
        })
        .catch(handleHeadlessError);
    }
    else if (command === "stop") {
      stop()
        .catch(handleHeadlessError);
    }
    else if (command === "forward") {
      forward()
        .catch(handleHeadlessError);
    }
    else if (command === "rewind") {
      rewind()
        .catch(handleHeadlessError);
    }
  });
}

/**
 * Listener for external calls
 */
if (typeof brapi !== 'undefined' && brapi.runtime && brapi.runtime.onMessageExternal) {
  brapi.runtime.onMessageExternal.addListener((request, sender) => {
    if (request.method === "play" && typeof request.text === "string") {
      playText(request.text)
        .catch(handleHeadlessError);
    }
    else if (request.method === "pause") {
      pause()
        .catch(handleHeadlessError);
    }
    else if (request.method === "stop") {
      stop()
        .catch(handleHeadlessError);
    }
    else if (request.method === "resume") {
      resume()
        .catch(handleHeadlessError);
    }
    else {
      handleHeadlessError(new Error("Bad method call"));
    }
  });
}

// Add message listener for processing selected text
if (typeof brapi !== 'undefined' && brapi.runtime && brapi.runtime.onMessage) {
  brapi.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.method === "processSelectedText") {
      (async () => {
        try {
          const translator = new MultiLanguageTranslator();
          if (request.sourceLanguage) {
            translator.setSourceLanguage(request.sourceLanguage);
          }
          if (request.targetLanguage) {
            translator.setTargetLanguage(request.targetLanguage);
          }
          const translation = await translator.translate(request.text);
          sendResponse({ 
            translatedText: translation || "Translation failed",
            sourceLanguage: translator.getSourceLanguage(),
            targetLanguage: translator.getTargetLanguage()
          });
        } catch (error) {
          handleHeadlessError(error);
          sendResponse({ error: error.message });
        }
      })();
      return true; // Required for async response
    }
    
    if (request.action === "backgroundTranslate") {
      const translator = new MultiLanguageTranslator();
      if (request.sourceLanguage) {
        translator.setSourceLanguage(request.sourceLanguage);
      }
      if (request.targetLanguage) {
        translator.setTargetLanguage(request.targetLanguage);
      }
      translator.translate(request.text)
        .then(result => sendResponse({ 
          translation: result,
          sourceLanguage: translator.getSourceLanguage(),
          targetLanguage: translator.getTargetLanguage()
        }))
        .catch(error => sendResponse({ error: error.message }));
      return true;
    }
    if (request.action === "openPopup") {
      const activeTab =  getActiveTab()
    chrome.windows.create({
      url: request.url+'?tab=' + (activeTab ? activeTab.id : ''),
      type: 'popup',
      width: request.options.width,
      height: request.options.height,
      left: request.options.left,
      top: request.options.top
    });
    sendResponse({ success: true });
  }

    if (request.action === "getSupportedLanguages") {
      sendResponse({ languages: SUPPORTED_LANGUAGES });
      return true;
    }

    if (request.method === "playSelectedText") {
      Promise.resolve()
        .then(function() {
          if (sender.tab && sender.tab.id != -1) return detectTabLanguage(sender.tab.id);
          else return undefined;
        })
        .then(function(lang) {
          return playText(request.text, {lang: lang});
        })
        .catch(handleHeadlessError);
    }
  });
}

/**
 * METHODS
 */
var currentTask = {
  task: null,
  isActive() {
    return this.task && this.task.isActive;
  },
  begin() {
    if (this.task) this.task.cancel();
    return this.task = {
      isActive: true,
      cancel() {
        this.isActive = false;
      },
      end() {
        if (!this.isActive) throw new Error("Canceled");
        this.isActive = false;
      }
    };
  },
  cancel() {
    if (this.task) {
      this.task.cancel();
      this.task = null;
    }
  }
};

async function playText(text, opts) {
  const hasPlayer = await stop().then(res => res === true, err => false);
  if (!hasPlayer) await injectPlayer(await getActiveTab());
  await sendToPlayer({method: "playText", args: [text, opts]});
}

async function playTab(tabId) {
  const tab = tabId ? await getTab(tabId) : await getActiveTab();
  if (!tab) throw new Error(JSON.stringify({code: "error_page_unreadable"}));

  const task = currentTask.begin();
  try {
    const handler = contentHandlers.find(h => h.match(tab.url || "", tab.title));
    if (handler && handler.validate) await handler.validate(tab);
    if (handler && handler.getSourceUri) {
      await brapi.storage.local.set({"sourceUri": handler.getSourceUri(tab)});
    }
    else {
      const frameId = handler && handler.getFrameId && await getAllFrames(tab.id).then(frames => handler.getFrameId(frames));
      if (!await contentScriptAlreadyInjected(tab, frameId)) await injectContentScript(tab, frameId, handler ? handler.extraScripts : []);
      await brapi.storage.local.set({"sourceUri": "contentscript:" + tab.id});
    }
  }
  finally {
    task.end();
  }

  const hasPlayer = await stop().then(res => res === true, err => false);
  if (!hasPlayer) await injectPlayer(tab);
  await sendToPlayer({method: "playTab"});
}

async function reloadAndPlayTab(tabId) {
  const tab = tabId ? await getTab(tabId) : await getActiveTab();

  const task = currentTask.begin();
  try {
    const tabLoadComplete = new Promise(fulfill => {
      function listener(changeTabId, changeInfo) {
        if (changeTabId === tab.id && changeInfo.status === "complete") {
          brapi.tabs.onUpdated.removeListener(listener);
          fulfill();
        }
      }
      brapi.tabs.onUpdated.addListener(listener);
    });
    await brapi.tabs.reload(tab.id);
    await tabLoadComplete;
  }
  finally {
    task.end();
  }

  await playTab(tab.id);
}

function stop() {
  currentTask.cancel();
  return sendToPlayer({method: "stop"});
}

function pause() {
  return sendToPlayer({method: "pause"});
}

function resume() {
  return sendToPlayer({method: "resume"});
}

async function getPlaybackState() {
  if (currentTask.isActive()) return {state: "LOADING"};
  try {
    return await sendToPlayer({method: "getPlaybackState"}) || {state: "STOPPED"};
  }
  catch (err) {
    return {state: "STOPPED"};
  }
}

function forward() {
  return sendToPlayer({method: "forward"});
}

function rewind() {
  return sendToPlayer({method: "rewind"});
}

function seek(n) {
  return sendToPlayer({method: "seek", args: [n]});
}

function handleHeadlessError(err) {
  console.error(err);
  //TODO: let user knows somehow
}

function reportIssue(url, comment) {
  var manifest = brapi.runtime.getManifest();
  return getSettings()
    .then(function(settings) {
      if (url) settings.url = url;
      settings.version = manifest.version;
      settings.userAgent = navigator.userAgent;
      return ajaxPost(config.serviceUrl + "/read-aloud/report-issue", {
        url: JSON.stringify(settings),
        comment: comment
      });
    });
}

function authWavenet() {
  createTab("https://cloud.google.com/text-to-speech/#put-text-to-speech-into-action", true)
    .then(function(tab) {
      addRequestListener();
      brapi.tabs.onRemoved.addListener(onTabRemoved);
      return showInstructions();

      function addRequestListener() {
        brapi.webRequest.onBeforeRequest.addListener(onRequest, {
          urls: ["https://cxl-services.appspot.com/proxy*"],
          tabId: tab.id
        });
      }
      function onTabRemoved(tabId) {
        if (tabId === tab.id) {
          brapi.tabs.onRemoved.removeListener(onTabRemoved);
          brapi.webRequest.onBeforeRequest.removeListener(onRequest);
        }
      }
      function onRequest(details) {
        var parser = new URL(details.url);
        var qs = parser.search ? parseQueryString(parser.search) : {};
        if (qs.token) {
          updateSettings({gcpToken: qs.token});
          showSuccess();
        }
      }
      function showInstructions() {
        return brapi.scripting.executeScript({
          target: {tabId: tab.id},
          func: function() {
            var elem = document.createElement('DIV');
            elem.id = 'ra-notice';
            elem.style.position = 'fixed';
            elem.style.top = '0';
            elem.style.left = '0';
            elem.style.right = '0';
            elem.style.backgroundColor = 'yellow';
            elem.style.padding = '20px';
            elem.style.fontSize = 'larger';
            elem.style.zIndex = '999000';
            elem.style.textAlign = 'center';
            elem.innerHTML = 'Please click the blue SPEAK-IT button, then check the I-AM-NOT-A-ROBOT checkbox.';
            document.body.appendChild(elem);
          }
        });
      }
      function showSuccess() {
        return brapi.scripting.executeScript({
          target: {tabId: tab.id},
          func: function() {
            var elem = document.getElementById('ra-notice');
            elem.style.backgroundColor = '#0d0';
            elem.innerHTML = 'Successful, you can now use Google Wavenet voices. You may close this tab.';
          }
        });
      }
    });
}

async function openPdfViewer(tabId, pdfUrl) {
  const perms = {
    origins: ["http://*/", "https://*/"]
  };
  if (!await brapi.permissions.contains(perms)) {
    throw new Error(JSON.stringify({code: "error_add_permissions", perms: perms}));
  }
  await setTabUrl(tabId, brapi.runtime.getURL("pdf-viewer.html?url=" + encodeURIComponent(pdfUrl)));
  await new Promise(f => handlers.pdfViewerCheckIn = f);
}

async function managePiperVoices() {
  const result = await sendToPlayer({method: "managePiperVoices"}).catch(err => false);
  if (result !== "OK") {
    if (result === "POPOUT") await sendToPlayer({method: "close"});
    await injectPlayer();
    await sendToPlayer({method: "managePiperVoices"});
  }
}

async function contentScriptAlreadyInjected(tab, frameId) {
  const items = await brapi.scripting.executeScript({
    target: {
      tabId: tab.id,
      frameIds: frameId ? [frameId] : undefined,
    },
    func: function() {
      return typeof brapi !== "undefined";
    }
  });
  return items[0].result === true;
}

async function injectContentScript(tab, frameId, extraScripts) {
  await brapi.scripting.executeScript({
    target: {
      tabId: tab.id,
      frameIds: frameId ? [frameId] : undefined,
    },
    files: [
      "js/rxjs.umd.min.js",
      "js/jquery-3.7.1.min.js",
      "js/defaults.js",
      "js/messaging.js",
      "js/content.js",
      "js/translator.js",
    ]
  });
  const files = extraScripts || await brapi.tabs.sendMessage(tab.id, {dest: "contentScript", method: "getRequireJs"});
  await brapi.scripting.executeScript({
    target: {
      tabId: tab.id,
      frameIds: frameId ? [frameId] : undefined,
    },
    files: files
  });
  console.info("Content handler", files);
}

async function injectPlayer(tab) {
  const settings = await getSettings(["useEmbeddedPlayer", "piperVoices"]);
  const promise = new Promise(f => handlers.playerCheckIn = f);
  if (tab && settings.useEmbeddedPlayer && (settings.piperVoices || []).length === 0) {
  try {
      if (tab.incognito) {
        throw new Error("Incognito tab");
      }
      await brapi.scripting.executeScript({
        target: {tabId: tab.id},
        func: createPlayerFrame
      });
    }
    catch (err) {
      console.warn("Cannot embed player", err);
      await createPlayerTab();
    }
  }
  else {
    await createPlayerTab();
  }
  await promise;
}

function createPlayerFrame() {
  const brapi = (typeof chrome !== 'undefined') ? chrome : (typeof browser !== 'undefined' ? browser : {});
  const frame = document.createElement("iframe");
  frame.src = brapi.runtime.getURL("player.html");
  frame.style.position = "absolute";
  frame.style.height = "0";
  frame.style.borderWidth = "0";
  document.body.appendChild(frame);
}

async function createPlayerTab() {
  const tab = await brapi.tabs.create({
    url: brapi.runtime.getURL("player.html?autoclose"),
    index: 0,
    active: false,
  });
  await brapi.tabs.update(tab.id, {pinned: true});
}

async function sendToPlayer(message) {
  message.dest = "player";
  const result = await brapi.runtime.sendMessage(message);
  if (result && result.error) throw result.error;
  else return result;
}

// Function to handle translation and playback
async function translateAndPlaySelection(text, tab, languageKey = 'hindi') {
  try {
    const lang = tab && tab.id != -1 
      ? await detectTabLanguage(tab.id) 
      : undefined;

    const translator = new MultiLanguageTranslator();
    const translatedText = await translator.translate(text, 'auto', languageKey);

    await playText(text, {lang: lang});

    if (translatedText && tab) {
      brapi.tabs.sendMessage(tab.id, {
        action: "showTranslation",
        originalText: text,
        translatedText: translatedText,
        targetLanguage: SUPPORTED_LANGUAGES[languageKey].name
      }).catch(err => console.error("Could not send translation to content script:", err));
    }

    return translatedText;
  } catch (error) {
    handleHeadlessError(error);
    throw error;
  }
}

// Helper functions
function registerMessageListener(dest, handlers) {
  if (typeof brapi !== 'undefined' && brapi.runtime && brapi.runtime.onMessage) {
    brapi.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.dest === dest && handlers[request.method]) {
        return handlers[request.method](...request.args || []);
      }
    });
  }
}

async function getActiveTab() {
  if (typeof brapi !== 'undefined' && brapi.tabs) {
    const tabs = await brapi.tabs.query({active: true, currentWindow: true});
    return tabs[0];
  }
  return null;
}

async function getTab(tabId) {
  if (typeof brapi !== 'undefined' && brapi.tabs) {
    return await brapi.tabs.get(tabId);
  }
  return null;
}

async function detectTabLanguage(tabId) {
  // Implement language detection logic here
  return 'en'; // Default to English
}

function getAllFrames(tabId) {
  if (typeof brapi !== 'undefined' && brapi.webNavigation) {
    return brapi.webNavigation.getAllFrames({tabId: tabId});
  }
  return Promise.resolve([]);
}


function setTabUrl(tabId, url) {
  if (typeof brapi !== 'undefined' && brapi.tabs) {
    return brapi.tabs.update(tabId, {url: url});
  }
  return Promise.resolve();
}

function createTab(url, active) {
  if (typeof brapi !== 'undefined' && brapi.tabs) {
    return brapi.tabs.create({url: url, active: active});
  }
  return Promise.resolve({id: -1});
}

function getSettings(keys) {
  if (typeof brapi !== 'undefined' && brapi.storage) {
    return brapi.storage.local.get(keys);
  }
  return Promise.resolve({});
}

function updateSettings(settings) {
  if (typeof brapi !== 'undefined' && brapi.storage) {
    return brapi.storage.local.set(settings);
  }
  return Promise.resolve();
}

function ajaxPost(url, data) {
  return fetch(url, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(data)
  }).then(r => r.json());
}

function parseQueryString(queryString) {
  const params = {};
  const pairs = queryString.substring(1).split('&');
  for (let i = 0; i < pairs.length; i++) {
    const pair = pairs[i].split('=');
    params[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1] || '');
  }
  return params;
}

// Content handlers (you need to define these)
var contentHandlers = [
  {
    match: function(url, title) {
      return url.includes('docs.google.com/document');
    },
    getRequireJs: function() {
      return ['js/page/google-doc.js'];
    }
  }
];

// Inject when extension is installed
if (typeof brapi !== 'undefined' && brapi.runtime && brapi.runtime.onInstalled) {
  brapi.runtime.onInstalled.addListener(() => {
    brapi.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        if (tab.url && tab.url.startsWith('http')) {
          injectDoubleClickHandler(tab.id);
        }
      });
    });
  });
}

// Inject when new tabs are created
if (typeof brapi !== 'undefined' && brapi.tabs && brapi.tabs.onUpdated) {
  brapi.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url && tab.url.startsWith('http')) {
      injectDoubleClickHandler(tabId);
    }
  });
}

// Function to inject the double-click handler
async function injectDoubleClickHandler(tabId) {
  try {
    await brapi.scripting.executeScript({
      target: {tabId: tabId},
      files: ['js/content/doubleClickHandler.js']
    });
  } catch (err) {
    console.error("Failed to inject double-click handler:", err);
  }
}

console.log('Background script loaded successfully with multi-language support');