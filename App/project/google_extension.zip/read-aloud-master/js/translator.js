// translator.js - Multilanguage support, direction via parameters
(function() {
    'use strict';
    
    console.log('Loading MultiLangTranslator...');

    function MultiLangTranslator() {
        this.apis = [
            this.myMemoryTranslate.bind(this),
            this.googleTranslateFallback.bind(this),
            this.libretranslateFallback.bind(this)
        ];
    }

    /**
     * Translate text from sourceLang to targetLang.
     * @param {string} text 
     * @param {string} sourceLang - ISO code (e.g. 'en')
     * @param {string} targetLang - ISO code (e.g. 'hi')
     * @returns {Promise<string>}
     */
    MultiLangTranslator.prototype.translate = function(text, sourceLang, targetLang) {
        var self = this;
        return new Promise(function(resolve, reject) {
            if (!text || typeof text !== 'string' || text.trim() === '') {
                resolve(text);
                return;
            }
            if (!sourceLang || !targetLang) {
                reject(new Error('Source and target languages are required'));
                return;
            }

            // Try each API sequentially
            var tryApi = function(index) {
                if (index >= self.apis.length) {
                    reject(new Error('All translation APIs failed'));
                    return;
                }

                self.apis[index](text, sourceLang, targetLang)
                    .then(function(result) {
                        if (result && result !== text) {
                            resolve(result);
                        } else {
                            tryApi(index + 1);
                        }
                    })
                    .catch(function(error) {
                        console.warn('Translation API failed:', error);
                        tryApi(index + 1);
                    });
            };

            tryApi(0);
        });
    };

    MultiLangTranslator.prototype.myMemoryTranslate = function(text, sourceLang, targetLang) {
        // MyMemory uses 'auto' for autodetect
        const sl = sourceLang === 'auto' ? 'auto' : sourceLang;
        return fetch(
            'https://api.mymemory.translated.net/get?q=' + 
            encodeURIComponent(text) + 
            '&langpair=' + encodeURIComponent(sl) + '|' + encodeURIComponent(targetLang)
        )
        .then(function(response) {
            if (!response.ok) throw new Error('MyMemory API error: ' + response.status);
            return response.json();
        })
        .then(function(data) {
            return data.responseData.translatedText;
        });
    };

    MultiLangTranslator.prototype.googleTranslateFallback = function(text, sourceLang, targetLang) {
        // Google API uses 'auto' for autodetect
        const sl = sourceLang === 'auto' ? 'auto' : sourceLang;
        return fetch(
            'https://translate.googleapis.com/translate_a/single?client=gtx&sl=' +
            encodeURIComponent(sl) + '&tl=' + encodeURIComponent(targetLang) + '&dt=t&q=' +
            encodeURIComponent(text)
        )
        .then(function(response) {
            if (!response.ok) throw new Error('Google Translate API error: ' + response.status);
            return response.json();
        })
        .then(function(data) {
            // Defensive: data[0][0][0] is the translated text
            if (Array.isArray(data) && Array.isArray(data[0]) && Array.isArray(data[0][0])) {
                return data[0][0][0];
            }
            throw new Error('Unexpected Google Translate API response');
        });
    };

    MultiLangTranslator.prototype.libretranslateFallback = function(text, sourceLang, targetLang) {
        // LibreTranslate uses 'auto' for autodetect
        const sl = sourceLang === 'auto' ? 'auto' : sourceLang;
        return fetch('https://libretranslate.com/translate', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify({
                q: text,
                source: sl,
                target: targetLang,
                format: 'text'
            })
        })
        .then(function(response) {
            if (!response.ok) throw new Error('LibreTranslate API error: ' + response.status);
            return response.json();
        })
        .then(function(data) {
            return data.translatedText;
        });
    };

    // Expose to global scope
    window.MultiLangTranslator = MultiLangTranslator;
    console.log('MultiLangTranslator loaded successfully');
})();